import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DeviceSwitcher } from './components/layout/DeviceSwitcher';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { HomeView } from './components/views/HomeView';
import { TransactionsView } from './components/views/TransactionsView';
import { ReportsView } from './components/views/ReportsView';
import { GoalsView } from './components/views/GoalsView';
import { BillsView } from './components/views/BillsView';
import { CalendarDashboardView } from './components/views/CalendarDashboardView';
import { SettingsView } from './components/views/SettingsView';
import { GroupSplitterView } from './components/views/GroupSplitterView';
import { LoansView } from './components/views/LoansView';
import { ArchiveView } from './components/views/ArchiveView';
import { WeeklyChallengesView } from './components/views/WeeklyChallengesView';
import { TransactionModal } from './components/modals/TransactionModal';
import { AIAssistantModal } from './components/ai/AIAssistantModal';
import { GamificationView } from './components/drawers/GamificationView';
import { SecurityLockScreen } from './components/security/SecurityLockScreen';
import { ToastContainer } from './components/common/ToastContainer';
import { LoginScreen } from './components/auth/LoginScreen';

const MainLayout: React.FC = () => {
  const { activeTab, deviceFrame, isLoggedIn } = useApp();

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  const renderActiveView = () => {
    switch (activeTab) {
      case 'home': return <HomeView />;
      case 'transactions': return <TransactionsView />;
      case 'reports': return <ReportsView />;
      case 'goals': return <GoalsView />;
      case 'bills': return <BillsView />;
      case 'calendar': return <CalendarDashboardView />;
      case 'splitwise': return <GroupSplitterView />;
      case 'loans': return <LoansView />;
      case 'archive': return <ArchiveView />;
      case 'challenges': return <WeeklyChallengesView />;
      case 'settings': return <SettingsView />;
      default: return <HomeView />;
    }
  };

  const isMobileFrame = deviceFrame === 'android' || deviceFrame === 'ios';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-gray-100 to-purple-50 dark:from-[#0a0a0a] dark:via-[#121212] dark:to-[#181824] flex flex-col font-sans transition-colors duration-300">
      {/* Top Viewport Frame Switcher Banner */}
      <DeviceSwitcher />

      <ToastContainer />
      <SecurityLockScreen />

      {/* Main Container Wrapper */}
      <div className={`flex-1 flex justify-center w-full ${isMobileFrame ? 'py-4 sm:py-6 px-2' : ''}`}>
        <div
          className={`w-full transition-all duration-300 flex flex-col bg-white dark:bg-[#121212] ${
            deviceFrame === 'android'
              ? 'max-w-[412px] h-[850px] rounded-[48px] border-[10px] border-gray-900 dark:border-gray-800 shadow-2xl overflow-hidden relative'
              : deviceFrame === 'ios'
              ? 'max-w-[393px] h-[844px] rounded-[50px] border-[12px] border-slate-900 shadow-2xl overflow-hidden relative'
              : 'max-w-4xl min-h-screen shadow-xl border-x border-gray-200/50 dark:border-white/5'
          }`}
        >
          {/* Simulated Mobile Camera Notch */}
          {deviceFrame === 'android' && (
            <div className="w-full flex justify-center pt-2 pb-1 bg-white dark:bg-[#121212] z-50 shrink-0">
              <div className="w-4 h-4 rounded-full bg-black/80" />
            </div>
          )}
          {deviceFrame === 'ios' && (
            <div className="w-full flex justify-center pt-2 pb-1 bg-white dark:bg-[#121212] z-50 shrink-0">
              <div className="w-28 h-6 rounded-full bg-black/90" />
            </div>
          )}

          {/* Top Header */}
          <Header />

          {/* Scrollable View Content */}
          <main className="flex-1 p-3 sm:p-5 overflow-y-auto relative">
            {renderActiveView()}
          </main>

          {/* Bottom Floating Navigation */}
          <BottomNav />

          {/* Modals & Drawers */}
          <TransactionModal />
          <AIAssistantModal />
          <GamificationView />
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
