import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bot, Send, Sparkles, X, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
}

export const AIAssistantModal: React.FC = () => {
  const { isAiModalOpen, setIsAiModalOpen, currentBalance, totalExpense, settings, addTransaction, showToast } = useApp();

  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: `Hello ${settings.userName}! I am MoneyFlow AI 🤖. How can I help you analyze your budget, save money, or log transactions today?`
    }
  ]);

  if (!isAiModalOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userText = input.trim();
    const userMsg: Message = { id: Date.now().toString(), sender: 'user', text: userText };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Generate smart response based on context
    setTimeout(() => {
      let aiResponse = "I'm analyzing your MoneyFlow data...";

      const lower = userText.toLowerCase();
      if (lower.includes('balance') || lower.includes('how much')) {
        aiResponse = `Your current balance is ${settings.currency}${currentBalance.toLocaleString()}. You have spent ${settings.currency}${totalExpense.toLocaleString()} this month.`;
      } else if (lower.includes('food') || lower.includes('lunch') || lower.includes('dinner')) {
        aiResponse = `You have spent ₹3,500 on Food this month. This accounts for ~32% of your total expenses. Tip: Cooking at home twice a week can save you ~₹1,200!`;
      } else if (lower.includes('log') || lower.includes('add')) {
        addTransaction({
          type: 'expense',
          amount: 250,
          category: 'Food',
          description: 'AI Auto-Logged Meal',
          date: new Date().toISOString().split('T')[0],
          paymentMethod: 'UPI',
          notes: 'Logged via MoneyFlow AI Assistant'
        });
        aiResponse = `Got it! I have automatically logged an expense of ${settings.currency}250 under Food (UPI).`;
      } else {
        aiResponse = `Great financial habit! Remember that setting aside at least 20% of your income into savings goals like "Buy Bike" or "Emergency Fund" keeps your financial health score strong!`;
      }

      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), sender: 'ai', text: aiResponse }]);
    }, 1000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-3xl p-5 shadow-2xl space-y-4 border border-purple-500/30 flex flex-col h-[75vh]"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-white/5 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white shadow-md">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-1.5">
                  MoneyFlow AI <Sparkles className="w-4 h-4 text-purple-500 fill-purple-500" />
                </h3>
                <p className="text-[11px] text-gray-400">Smart Financial Assistant</p>
              </div>
            </div>

            <button onClick={() => setIsAiModalOpen(false)}>
              <X className="w-5 h-5 text-gray-400 hover:text-white" />
            </button>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 p-1">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                  msg.sender === 'user' ? 'bg-purple-600 text-white' : 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300'
                }`}>
                  {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className={`p-3.5 rounded-2xl text-xs max-w-[80%] leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-purple-600 text-white font-medium rounded-tr-none'
                    : 'bg-gray-100 dark:bg-white/5 text-gray-800 dark:text-gray-200 rounded-tl-none border border-gray-200/50 dark:border-white/5'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          {/* Quick Prompts */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            <button
              onClick={() => setInput('What is my current balance?')}
              className="px-3 py-1 rounded-full bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-300 text-[10px] font-bold border border-purple-200 dark:border-purple-800/40 shrink-0 hover:bg-purple-100"
            >
              💡 Check Balance
            </button>
            <button
              onClick={() => setInput('Log 250 for Food')}
              className="px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-300 text-[10px] font-bold border border-emerald-200 dark:border-emerald-800/40 shrink-0 hover:bg-emerald-100"
            >
              ➕ Quick Log ₹250
            </button>
            <button
              onClick={() => setInput('How to save more money?')}
              className="px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-300 text-[10px] font-bold border border-amber-200 dark:border-amber-800/40 shrink-0 hover:bg-amber-100"
            >
              🎯 Savings Tips
            </button>
          </div>

          {/* Input Box */}
          <form onSubmit={handleSend} className="flex items-center gap-2 pt-2 border-t border-gray-100 dark:border-white/5">
            <input
              type="text"
              placeholder="Ask AI anything or log an expense..."
              value={input}
              onChange={e => setInput(e.target.value)}
              className="flex-1 p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
            />
            <button
              type="submit"
              className="p-3 rounded-2xl bg-purple-600 text-white hover:bg-purple-700 transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
