import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, ArrowRight, User, Lock, DollarSign, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export const LoginScreen: React.FC = () => {
  const { loginUser } = useApp();
  const [userName, setUserName] = useState('');
  const [pin, setPin] = useState('');
  const [currency, setCurrency] = useState('₹');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) return;

    loginUser(userName.trim(), pin || '1234', currency);
  };

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 text-white flex flex-col items-center justify-center p-6 space-y-6 animate-fadeIn">
      {/* App Logo */}
      <div className="flex flex-col items-center space-y-3 text-center">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-500 to-pink-500 flex items-center justify-center text-white shadow-2xl shadow-purple-500/40">
          <span className="font-black text-4xl tracking-tighter">M</span>
        </div>
        <h1 className="text-3xl font-black tracking-tight bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          MoneyFlow
        </h1>
        <p className="text-xs text-gray-300 font-medium max-w-xs">
          Simple, beautiful & smart money manager. Login or enter your PIN to start fresh.
        </p>
      </div>

      {/* Login Card */}
      <motion.form
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        onSubmit={handleSubmit}
        className="w-full max-w-sm glass-card p-6 rounded-3xl space-y-4 border border-white/10 shadow-2xl backdrop-blur-2xl"
      >
        <div>
          <label className="text-xs font-bold text-gray-300 uppercase block mb-1.5 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-purple-400" /> Enter Your Name
          </label>
          <input
            type="text"
            placeholder="e.g. Namit, Alex"
            value={userName}
            onChange={e => setUserName(e.target.value)}
            className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/10 text-xs font-bold text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
            required
            autoFocus
          />
        </div>

        <div>
          <label className="text-xs font-bold text-gray-300 uppercase block mb-1.5 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-purple-400" /> 4-Digit Login PIN Code
          </label>
          <input
            type="password"
            maxLength={4}
            placeholder="e.g. 1234"
            value={pin}
            onChange={e => setPin(e.target.value)}
            className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/10 text-xs font-bold text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 text-center tracking-widest text-lg"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-gray-300 uppercase block mb-1.5 flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-purple-400" /> Default Currency
          </label>
          <select
            value={currency}
            onChange={e => setCurrency(e.target.value)}
            className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/10 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="₹" className="bg-slate-900 text-white">₹ (INR - Rupee)</option>
            <option value="$" className="bg-slate-900 text-white">$ (USD - Dollar)</option>
            <option value="€" className="bg-slate-900 text-white">€ (EUR - Euro)</option>
            <option value="£" className="bg-slate-900 text-white">£ (GBP - Pound)</option>
            <option value="¥" className="bg-slate-900 text-white">¥ (JPY - Yen)</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-amber-400 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-95 transition-all mt-2"
        >
          <span>Start Fresh MoneyFlow</span>
          <ArrowRight className="w-4 h-4 stroke-[3]" />
        </button>
      </motion.form>
    </div>
  );
};
