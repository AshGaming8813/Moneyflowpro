import React from 'react';
import * as Icons from 'lucide-react';
import { CATEGORIES } from '../../constants/defaultData';
import { CategoryName } from '../../types';

interface CategoryIconProps {
  category: CategoryName | string;
  size?: number;
  className?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ 
  category, 
  size = 20, 
  className = '' 
}) => {
  const categoryInfo = CATEGORIES.find(c => c.name.toLowerCase() === category.toLowerCase()) || {
    name: category,
    icon: 'MoreHorizontal',
    color: 'bg-purple-500 text-white',
    type: 'both'
  };

  // Dynamic Lucide icon loader
  const IconComponent = (Icons as unknown as Record<string, React.ElementType>)[categoryInfo.icon] || Icons.HelpCircle;

  return (
    <div className={`p-2.5 rounded-2xl flex items-center justify-center shadow-sm shrink-0 ${categoryInfo.color} ${className}`}>
      <IconComponent size={size} />
    </div>
  );
};
