import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, TrendingUp, Sparkles, Info, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

export const FinancialHealthScore: React.FC = () => {
  const { currentBalance, totalIncome, totalExpense, transactions } = useApp();

  const hasTransactions = transactions.length > 0;

  let score = 0;
  let grade = '0 / 900';
  let gradeColor = 'text-gray-400';
  let isDeficit = false;

  if (!hasTransactions) {
    score = 0;
    grade = 'New Account (0)';
    gradeColor = 'text-gray-400';
  } else if (totalIncome === 0 && totalExpense > 0) {
    // 0 Income with Expenses = High Financial Deficit!
    isDeficit = true;
    score = Math.max(120, Math.round(300 - (totalExpense / 50)));
    grade = 'Critical Deficit 🔴';
    gradeColor = 'text-rose-500 font-black';
  } else if (totalExpense > totalIncome) {
    // Overspending Deficit
    isDeficit = true;
    const overspendRatio = (totalExpense - totalIncome) / totalIncome;
    score = Math.max(150, Math.round(450 - overspendRatio * 200));
    grade = 'Overspending ⚠️';
    gradeColor = 'text-orange-500 font-bold';
  } else {
    // Healthy Positive Savings
    const savingsRatio = totalIncome > 0 ? (totalIncome - totalExpense) / totalIncome : 0;
    score = Math.min(900, Math.round(500 + savingsRatio * 400));
    
    if (score >= 800) {
      grade = 'Excellent 🌟';
      gradeColor = 'text-emerald-400 font-extrabold';
    } else if (score >= 650) {
      grade = 'Very Good 👍';
      gradeColor = 'text-blue-400 font-extrabold';
    } else {
      grade = 'Fair Health';
      gradeColor = 'text-amber-400 font-bold';
    }
  }

  const savingsPercent = totalIncome > 0 ? Math.round(((totalIncome - totalExpense) / totalIncome) * 100) : 0;

  return (
    <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 text-white shadow-xl border border-purple-500/30 relative overflow-hidden space-y-4">
      {/* Background glow */}
      <div className="absolute -right-10 -bottom-10 w-36 h-36 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
            <ShieldCheck className="w-5 h-5 text-purple-300" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm text-purple-100 uppercase tracking-wider">
              Financial Health Score
            </h3>
            <p className="text-[11px] text-gray-400">CRED & Banking Grade Rating</p>
          </div>
        </div>

        <span className={`text-xs px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 ${gradeColor}`}>
          {grade}
        </span>
      </div>

      {/* Main Meter Rating Display */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <div className="flex items-baseline gap-1.5">
            <span className={`text-4xl font-black tracking-tight ${isDeficit ? 'text-rose-400' : 'text-white'}`}>
              {score}
            </span>
            <span className="text-xs text-gray-400 font-bold">/ 900</span>
          </div>
          <p className="text-xs font-semibold mt-1 flex items-center gap-1">
            {isDeficit ? (
              <span className="text-rose-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500" /> Expenses exceed income! Add income to improve score.
              </span>
            ) : hasTransactions ? (
              <span className="text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> Healthy positive cashflow
              </span>
            ) : (
              <span className="text-gray-400 flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-amber-400" /> Log income & expense entries to generate score
              </span>
            )}
          </p>
        </div>

        {/* Circular SVG Gauge visual */}
        <div className="relative w-20 h-20 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
            <path
              className="text-gray-800 stroke-current"
              strokeWidth="3.5"
              fill="none"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            />
            <motion.path
              initial={{ strokeDasharray: '0, 100' }}
              animate={{ strokeDasharray: `${(score / 900) * 100}, 100` }}
              transition={{ duration: 1.5, ease: 'easeOut' }}
              className={`${isDeficit ? 'text-rose-500' : 'text-purple-400'} stroke-current`}
              strokeWidth="3.5"
              strokeDasharray="94, 100"
              strokeLinecap="round"
              fill="none"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            />
          </svg>
          <Sparkles className="w-6 h-6 text-purple-300 absolute" />
        </div>
      </div>

      {/* Factor Ratings */}
      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10 text-[11px]">
        <div className="flex justify-between items-center bg-white/5 p-2 rounded-xl">
          <span className="text-gray-300">Savings Rate</span>
          <span className={`font-bold ${isDeficit ? 'text-rose-400' : 'text-emerald-400'}`}>
            {hasTransactions ? `${savingsPercent}%` : '0/250'}
          </span>
        </div>
        <div className="flex justify-between items-center bg-white/5 p-2 rounded-xl">
          <span className="text-gray-300">Bill Discipline</span>
          <span className={`font-bold ${isDeficit ? 'text-amber-400' : 'text-emerald-400'}`}>
            {hasTransactions ? (isDeficit ? '100/200' : '200/200') : '0/200'}
          </span>
        </div>
        <div className="flex justify-between items-center bg-white/5 p-2 rounded-xl">
          <span className="text-gray-300">Emergency Buffer</span>
          <span className={`font-bold ${isDeficit ? 'text-rose-400' : 'text-amber-300'}`}>
            {hasTransactions ? (isDeficit ? '0/250' : '195/250') : '0/250'}
          </span>
        </div>
        <div className="flex justify-between items-center bg-white/5 p-2 rounded-xl">
          <span className="text-gray-300">Debt Deficit</span>
          <span className={`font-bold ${isDeficit ? 'text-rose-400' : 'text-emerald-400'}`}>
            {isDeficit ? 'CRITICAL 🔴' : hasTransactions ? 'HEALTHY ✅' : '0/200'}
          </span>
        </div>
      </div>
    </div>
  );
};
