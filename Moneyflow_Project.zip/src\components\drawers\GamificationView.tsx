import React from 'react';
import { useApp } from '../../context/AppContext';
import { Trophy, Flame, Award, Crown, Zap, Shield, X, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const GamificationView: React.FC = () => {
  const { isGamificationModalOpen, setIsGamificationModalOpen, badges, streakCount, triggerConfetti } = useApp();

  if (!isGamificationModalOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-5 border border-white/20 dark:border-white/10 max-h-[85vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-amber-500 text-white shadow-lg shadow-amber-500/30">
                <Trophy className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-lg text-gray-900 dark:text-white">
                  Money Master Rewards 🏆
                </h3>
                <p className="text-xs text-gray-400">Earn badges and keep your saving streak alive</p>
              </div>
            </div>

            <button onClick={() => setIsGamificationModalOpen(false)}>
              <X className="w-5 h-5 text-gray-400 hover:text-gray-600 dark:hover:text-white" />
            </button>
          </div>

          {/* Streak Banner Card */}
          <div 
            onClick={triggerConfetti}
            className="p-5 rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white flex items-center justify-between shadow-xl cursor-pointer hover:scale-[1.01] transition-transform"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-md">
                <Flame className="w-7 h-7 text-amber-200 animate-pulse" />
              </div>
              <div>
                <span className="text-xs font-semibold text-amber-100 uppercase">Active Savings Streak</span>
                <p className="text-2xl font-black">{streakCount} Days Strong 🔥</p>
              </div>
            </div>
            <span className="text-xs bg-white text-orange-600 font-extrabold px-3 py-1.5 rounded-full shadow-md">
              Tap for Cheer!
            </span>
          </div>

          {/* Badges Grid */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Achievement Badges
            </h4>

            <div className="grid grid-cols-2 gap-3">
              {badges.map(badge => {
                const percent = Math.min(100, Math.round((badge.progress / badge.maxProgress) * 100));
                return (
                  <div
                    key={badge.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      badge.unlocked
                        ? 'bg-purple-500/10 border-purple-500/30 text-purple-900 dark:text-purple-200'
                        : 'bg-gray-100 dark:bg-white/5 border-gray-200 dark:border-white/5 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className={`p-2 rounded-xl text-white ${badge.unlocked ? 'bg-purple-600' : 'bg-gray-400'}`}>
                        {badge.unlocked ? <Award className="w-5 h-5" /> : <Shield className="w-5 h-5" />}
                      </div>
                      {badge.unlocked && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                    </div>

                    <h5 className="font-extrabold text-xs text-gray-900 dark:text-white">
                      {badge.title}
                    </h5>
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-0.5 line-clamp-2">
                      {badge.description}
                    </p>

                    {/* Progress */}
                    <div className="mt-3 space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-gray-400">
                        <span>Progress</span>
                        <span>{percent}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-gray-200 dark:bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-600 rounded-full"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
