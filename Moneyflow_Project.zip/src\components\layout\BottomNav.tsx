import React from 'react';
import { useApp } from '../../context/AppContext';
import { Home, ArrowLeftRight, PieChart, Building2, Settings, Plus, Users } from 'lucide-react';
import { NavTab } from '../../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, openAddModal, deviceFrame, t } = useApp();

  const leftNavItems: { id: NavTab; key: string; icon: React.ElementType }[] = [
    { id: 'home', key: 'homeTab', icon: Home },
    { id: 'transactions', key: 'historyTab', icon: ArrowLeftRight },
    { id: 'loans', key: 'loansTab', icon: Building2 },
  ];

  const rightNavItems: { id: NavTab; key: string; icon: React.ElementType }[] = [
    { id: 'splitwise', key: 'splitwiseTab', icon: Users },
    { id: 'reports', key: 'reportsTab', icon: PieChart },
    { id: 'settings', key: 'settingsTab', icon: Settings },
  ];

  const isMobileFrame = deviceFrame === 'android' || deviceFrame === 'ios';

  return (
    <div className={`${isMobileFrame ? 'sticky bottom-0' : 'fixed bottom-0 left-0 right-0'} z-40 px-2 pb-2 pt-1 pointer-events-none max-w-4xl mx-auto w-full`}>
      <div className="pointer-events-auto relative flex items-center justify-between px-2 py-2 rounded-3xl bg-white/95 dark:bg-[#1A1A1A]/95 shadow-2xl border border-gray-200/90 dark:border-white/10 backdrop-blur-2xl">
        {/* Left items */}
        <div className="flex items-center justify-around w-[44%]">
          {leftNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center gap-0.5 transition-all duration-200 ${
                  isActive
                    ? 'text-purple-600 dark:text-purple-400 scale-105 font-black'
                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 font-bold'
                }`}
              >
                <Icon className="w-4 h-4 stroke-[2.5]" />
                <span className="text-[10px] font-extrabold tracking-tight whitespace-nowrap">
                  {t(item.key)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Center Floating Plus Action Button */}
        <div className="relative -top-3.5 flex justify-center shrink-0">
          <button
            onClick={() => openAddModal('expense')}
            className="w-11 h-11 rounded-full bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 flex items-center justify-center text-white shadow-lg shadow-purple-500/40 hover:scale-105 active:scale-95 transition-all duration-300 ring-4 ring-white dark:ring-[#121212]"
            title="Add Expense / Income"
          >
            <Plus className="w-5 h-5 stroke-[3]" />
          </button>
        </div>

        {/* Right items */}
        <div className="flex items-center justify-around w-[44%]">
          {rightNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center gap-0.5 transition-all duration-200 ${
                  isActive
                    ? 'text-purple-600 dark:text-purple-400 scale-105 font-black'
                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 font-bold'
                }`}
              >
                <Icon className="w-4 h-4 stroke-[2.5]" />
                <span className="text-[10px] font-extrabold tracking-tight whitespace-nowrap">
                  {t(item.key)}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
