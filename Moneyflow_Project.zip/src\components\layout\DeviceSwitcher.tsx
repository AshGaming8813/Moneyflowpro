import React from 'react';
import { useApp } from '../../context/AppContext';
import { Smartphone, Monitor, ShieldCheck, Sparkles } from 'lucide-react';

export const DeviceSwitcher: React.FC = () => {
  const { deviceFrame, setDeviceFrame, setIsAiModalOpen, setIsGamificationModalOpen, streakCount } = useApp();

  return (
    <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white text-xs py-2 px-4 flex flex-wrap items-center justify-between shadow-md border-b border-purple-500/20">
      <div className="flex items-center gap-2">
        <span className="font-extrabold tracking-wider bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent text-sm">
          MoneyFlow
        </span>
        <span className="hidden sm:inline-block bg-purple-500/20 text-purple-300 text-[10px] px-2 py-0.5 rounded-full border border-purple-500/30">
          PRO v1.0
        </span>
      </div>

      {/* Frame selector pills */}
      <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl backdrop-blur-md border border-white/10">
        <button
          onClick={() => setDeviceFrame('android')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all font-medium ${
            deviceFrame === 'android'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-gray-400 hover:text-white'
          }`}
          title="Android Viewport"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Android</span>
        </button>

        <button
          onClick={() => setDeviceFrame('ios')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all font-medium ${
            deviceFrame === 'ios'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-gray-400 hover:text-white'
          }`}
          title="iOS Viewport"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>iOS</span>
        </button>

        <button
          onClick={() => setDeviceFrame('full')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all font-medium ${
            deviceFrame === 'full'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-gray-400 hover:text-white'
          }`}
          title="Responsive Web"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Full Web</span>
        </button>
      </div>

      <div className="hidden md:flex items-center gap-3">
        <button
          onClick={() => setIsGamificationModalOpen(true)}
          className="flex items-center gap-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 px-2.5 py-1 rounded-lg border border-amber-500/30 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>{streakCount} Day Streak</span>
        </button>

        <button
          onClick={() => setIsAiModalOpen(true)}
          className="flex items-center gap-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 px-2.5 py-1 rounded-lg border border-cyan-500/30 transition-all"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span>AI Assistant</span>
        </button>
      </div>
    </div>
  );
};
