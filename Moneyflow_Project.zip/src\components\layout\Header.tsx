import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { InvestmentCalculatorModal } from '../tools/InvestmentCalculatorModal';
import { BedtimeSummaryModal } from '../modals/BedtimeSummaryModal';
import { SMSParserModal } from '../modals/SMSParserModal';
import { ReceiptScannerModal } from '../modals/ReceiptScannerModal';
import { VoiceExpenseModal } from '../modals/VoiceExpenseModal';
import { WhatsAppShareModal } from '../tools/WhatsAppShareModal';
import { WalletType, AppLanguage } from '../../types';
import { 
  Sun, 
  Moon, 
  MessageSquareCode, 
  Camera, 
  Mic, 
  Share2, 
  Eye, 
  EyeOff, 
  User, 
  Briefcase, 
  Users, 
  LogOut,
  Sparkles,
  ChevronDown,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const Header: React.FC = () => {
  const { 
    settings, 
    toggleTheme, 
    setActiveTab, 
    switchWallet,
    togglePrivacyMode,
    updateSettings,
    logoutUser,
    t
  } = useApp();

  const [isCalcModalOpen, setIsCalcModalOpen] = useState(false);
  const [isSMSModalOpen, setIsSMSModalOpen] = useState(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  
  const [showToolsDropdown, setShowToolsDropdown] = useState(false);
  const [showWalletDropdown, setShowWalletDropdown] = useState(false);
  const [showQuickSettingsDropdown, setShowQuickSettingsDropdown] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-[100] px-3 py-2 bg-white/95 dark:bg-[#121212]/95 backdrop-blur-xl border-b border-gray-200/60 dark:border-white/10 shrink-0 w-full overflow-visible">
        <div className="flex items-center justify-between gap-1 w-full max-w-4xl mx-auto overflow-visible relative">
          {/* Left: App Logo */}
          <div 
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <div className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-500 to-pink-500 flex items-center justify-center text-white shadow-md shadow-purple-500/20">
              <span className="font-black text-sm tracking-tighter">M</span>
            </div>
            <span className="font-extrabold text-xs tracking-tight bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
              {t('appName')}
            </span>
          </div>

          {/* Right Compact Action Group */}
          <div className="flex items-center gap-1 shrink-0 overflow-visible relative">
            {/* Wallet Dropdown Pill */}
            <div className="relative overflow-visible z-[110]">
              <button
                onClick={() => {
                  setShowWalletDropdown(!showWalletDropdown);
                  setShowToolsDropdown(false);
                  setShowQuickSettingsDropdown(false);
                }}
                className="px-2 py-1 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 text-[10px] font-extrabold flex items-center gap-1 border border-purple-300/40 dark:border-purple-800/40 shadow-xs"
              >
                {settings.activeWallet === 'personal' && <User className="w-3 h-3 text-purple-600" />}
                {settings.activeWallet === 'business' && <Briefcase className="w-3 h-3 text-purple-600" />}
                {settings.activeWallet === 'family' && <Users className="w-3 h-3 text-purple-600" />}
                <span className="capitalize">{settings.activeWallet}</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              <AnimatePresence>
                {showWalletDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: 5, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 5, scale: 0.95 }}
                    className="absolute right-0 mt-1 w-36 bg-white dark:bg-[#1E1E1E] rounded-2xl p-1.5 shadow-2xl border border-gray-200 dark:border-white/10 z-[120] space-y-1 text-xs"
                  >
                    <button
                      onClick={() => { switchWallet('personal'); setShowWalletDropdown(false); }}
                      className={`w-full p-2 rounded-xl text-left font-bold flex items-center gap-2 ${
                        settings.activeWallet === 'personal' ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' : 'hover:bg-gray-100 dark:hover:bg-white/5'
                      }`}
                    >
                      <User className="w-3.5 h-3.5 text-purple-600" /> Personal
                    </button>
                    <button
                      onClick={() => { switchWallet('business'); setShowWalletDropdown(false); }}
                      className={`w-full p-2 rounded-xl text-left font-bold flex items-center gap-2 ${
                        settings.activeWallet === 'business' ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' : 'hover:bg-gray-100 dark:hover:bg-white/5'
                      }`}
                    >
                      <Briefcase className="w-3.5 h-3.5 text-purple-600" /> Business
                    </button>
                    <button
                      onClick={() => { switchWallet('family'); setShowWalletDropdown(false); }}
                      className={`w-full p-2 rounded-xl text-left font-bold flex items-center gap-2 ${
                        settings.activeWallet === 'family' ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' : 'hover:bg-gray-100 dark:hover:bg-white/5'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5 text-purple-600" /> Family
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Tools Dropdown Pill */}
            <div className="relative overflow-visible z-[110]">
              <button
                onClick={() => {
                  setShowToolsDropdown(!showToolsDropdown);
                  setShowWalletDropdown(false);
                  setShowQuickSettingsDropdown(false);
                }}
                className="px-2 py-1 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-300 text-[10px] font-extrabold flex items-center gap-1 border border-purple-500/20 shadow-xs"
              >
                <Sparkles className="w-3 h-3 text-purple-500" />
                <span>Tools</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              <AnimatePresence>
                {showToolsDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: 5, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 5, scale: 0.95 }}
                    className="absolute right-0 mt-1 w-44 bg-white dark:bg-[#1E1E1E] rounded-2xl p-1.5 shadow-2xl border border-gray-200 dark:border-white/10 z-[120] space-y-1 text-xs"
                  >
                    <button
                      onClick={() => { setIsSMSModalOpen(true); setShowToolsDropdown(false); }}
                      className="w-full p-2 rounded-xl text-left hover:bg-purple-50 dark:hover:bg-white/5 font-bold flex items-center gap-2 text-purple-600 dark:text-purple-300"
                    >
                      <MessageSquareCode className="w-3.5 h-3.5" /> Bank SMS Parser
                    </button>

                    <button
                      onClick={() => { setIsReceiptModalOpen(true); setShowToolsDropdown(false); }}
                      className="w-full p-2 rounded-xl text-left hover:bg-amber-50 dark:hover:bg-white/5 font-bold flex items-center gap-2 text-amber-500"
                    >
                      <Camera className="w-3.5 h-3.5" /> Receipt OCR Scanner
                    </button>

                    <button
                      onClick={() => { setIsVoiceModalOpen(true); setShowToolsDropdown(false); }}
                      className="w-full p-2 rounded-xl text-left hover:bg-pink-50 dark:hover:bg-white/5 font-bold flex items-center gap-2 text-pink-500"
                    >
                      <Mic className="w-3.5 h-3.5" /> Voice AI Entry
                    </button>

                    <button
                      onClick={() => { setIsWhatsAppModalOpen(true); setShowToolsDropdown(false); }}
                      className="w-full p-2 rounded-xl text-left hover:bg-emerald-50 dark:hover:bg-white/5 font-bold flex items-center gap-2 text-emerald-500"
                    >
                      <Share2 className="w-3.5 h-3.5" /> Share on WhatsApp
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Privacy Mode Eye Toggle */}
            <button
              onClick={togglePrivacyMode}
              className="p-1 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/10 transition-all"
              title={settings.isPrivacyMode ? 'Show Balance' : 'Hide Balance'}
            >
              {settings.isPrivacyMode ? <EyeOff className="w-3.5 h-3.5 text-rose-500" /> : <Eye className="w-3.5 h-3.5 text-purple-600" />}
            </button>

            {/* Quick Settings Dropdown (Language, Theme & Logout) */}
            <div className="relative overflow-visible z-[110]">
              <button
                onClick={() => {
                  setShowQuickSettingsDropdown(!showQuickSettingsDropdown);
                  setShowWalletDropdown(false);
                  setShowToolsDropdown(false);
                }}
                className="w-7 h-7 rounded-full ring-2 ring-purple-500/30 overflow-hidden cursor-pointer hover:ring-purple-500 transition-all shrink-0"
              >
                <img 
                  src={settings.userAvatar} 
                  alt={settings.userName}
                  className="w-full h-full object-cover"
                />
              </button>

              <AnimatePresence>
                {showQuickSettingsDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: 5, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 5, scale: 0.95 }}
                    className="absolute right-0 mt-1 w-44 bg-white dark:bg-[#1E1E1E] rounded-2xl p-2 shadow-2xl border border-gray-200 dark:border-white/10 z-[120] space-y-2 text-xs"
                  >
                    <div className="px-2 py-1 border-b border-gray-100 dark:border-white/5">
                      <span className="font-extrabold text-gray-900 dark:text-white block truncate">{settings.userName}</span>
                      <span className="text-[10px] text-gray-400">MoneyFlow User</span>
                    </div>

                    <div className="flex items-center justify-between px-2">
                      <span className="text-[11px] font-bold text-gray-500">Language</span>
                      <select
                        value={settings.language}
                        onChange={e => updateSettings({ language: e.target.value as AppLanguage })}
                        className="bg-gray-100 dark:bg-white/10 text-gray-800 dark:text-white text-[10px] font-bold py-0.5 px-1 rounded-lg focus:outline-none cursor-pointer"
                      >
                        <option value="en">EN</option>
                        <option value="hi">HI</option>
                        <option value="mr">MR</option>
                        <option value="pa">PA</option>
                        <option value="gu">GU</option>
                        <option value="ta">TA</option>
                        <option value="bn">BN</option>
                      </select>
                    </div>

                    <button
                      onClick={toggleTheme}
                      className="w-full p-2 rounded-xl text-left font-bold flex items-center justify-between hover:bg-gray-100 dark:hover:bg-white/5 text-gray-700 dark:text-gray-300"
                    >
                      <span>Theme Mode</span>
                      {settings.theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-indigo-600" />}
                    </button>

                    <button
                      onClick={() => { setActiveTab('settings'); setShowQuickSettingsDropdown(false); }}
                      className="w-full p-2 rounded-xl text-left font-bold flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-white/5 text-gray-700 dark:text-gray-300"
                    >
                      <Settings className="w-3.5 h-3.5" /> App Settings
                    </button>

                    <button
                      onClick={logoutUser}
                      className="w-full p-2 rounded-xl text-left font-bold flex items-center gap-2 hover:bg-rose-50 text-rose-500 dark:hover:bg-rose-950/40"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Logout
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>

      {/* Modals */}
      <InvestmentCalculatorModal isOpen={isCalcModalOpen} onClose={() => setIsCalcModalOpen(false)} />
      <BedtimeSummaryModal />
      <SMSParserModal isOpen={isSMSModalOpen} onClose={() => setIsSMSModalOpen(false)} />
      <ReceiptScannerModal isOpen={isReceiptModalOpen} onClose={() => setIsReceiptModalOpen(false)} />
      <VoiceExpenseModal isOpen={isVoiceModalOpen} onClose={() => setIsVoiceModalOpen(false)} />
      <WhatsAppShareModal isOpen={isWhatsAppModalOpen} onClose={() => setIsWhatsAppModalOpen(false)} />
    </>
  );
};
