import React from 'react';
import { useApp } from '../../context/AppContext';
import { Moon, Sparkles, X, Heart, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const BedtimeSummaryModal: React.FC = () => {
  const { isBedtimeSummaryOpen, setIsBedtimeSummaryOpen, todayExpense, todayIncome, settings, triggerConfetti } = useApp();

  if (!isBedtimeSummaryOpen) return null;

  const savedToday = Math.max(0, settings.dailyLimit - todayExpense);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-md bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 text-white rounded-3xl p-6 shadow-2xl space-y-5 border border-purple-500/30 text-center relative overflow-hidden"
        >
          {/* Header Icon */}
          <div className="w-16 h-16 rounded-full bg-purple-500/20 border border-purple-400/30 flex items-center justify-center mx-auto text-amber-300">
            <Moon className="w-8 h-8 fill-amber-300 animate-pulse" />
          </div>

          <div className="space-y-1">
            <h3 className="text-xl font-black text-white flex items-center justify-center gap-1.5">
              Nightly Summary 🌙
            </h3>
            <p className="text-xs text-gray-300">Here is how you managed money today</p>
          </div>

          {/* Daily Card */}
          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 space-y-3">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-white/5">
                <span className="text-gray-400 text-[10px] uppercase block">Today Spent</span>
                <span className="text-base font-extrabold text-rose-400">
                  {settings.currency}{todayExpense.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5">
                <span className="text-gray-400 text-[10px] uppercase block">Daily Surplus Saved</span>
                <span className="text-base font-extrabold text-emerald-400">
                  +{settings.currency}{savedToday.toLocaleString()}
                </span>
              </div>
            </div>

            <p className="text-xs font-semibold text-purple-200">
              "Great financial discipline today, {settings.userName}! You stayed well within your daily limit." 🎉
            </p>
          </div>

          <button
            onClick={() => {
              triggerConfetti();
              setIsBedtimeSummaryOpen(false);
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-extrabold text-xs shadow-lg hover:scale-[1.01] transition-transform"
          >
            Goodnight! Sleep Well 😴
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
