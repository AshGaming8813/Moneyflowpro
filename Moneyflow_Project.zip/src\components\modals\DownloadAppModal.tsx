import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Download, 
  Smartphone, 
  Monitor, 
  QrCode, 
  X, 
  CheckCircle2, 
  Sparkles, 
  Share2, 
  ShieldCheck, 
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const { showToast } = useApp();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [activeTab, setActiveTab] = useState<'mobile' | 'apk' | 'desktop' | 'qr'>('mobile');

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast('MoneyFlow App installed on device!', 'success');
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      // Fallback instructions
      showToast('Tap "Add to Home Screen" in your browser menu to install!', 'info');
    }
  };

  const handleDownloadAPK = () => {
    showToast('Preparing MoneyFlow_v1.0.0.apk package...', 'info');
    setTimeout(() => {
      // Generate downloadable manifest / dummy APK package
      const content = `MoneyFlow Mobile Android Application Package v1.0.0\nApp ID: com.moneyflow.app\nBuild: Production Release`;
      const blob = new Blob([content], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'MoneyFlow_v1.0.0.apk';
      a.click();
      showToast('MoneyFlow_v1.0.0.apk downloaded successfully!', 'success');
    }, 1500);
  };

  const handleDownloadDesktop = () => {
    showToast('Downloading MoneyFlow Desktop Setup for Windows/Mac...', 'info');
    setTimeout(() => {
      const content = `MoneyFlow Desktop Installer v1.0.0`;
      const blob = new Blob([content], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'MoneyFlow_Setup_v1.0.0.exe';
      a.click();
      showToast('MoneyFlow Desktop Setup downloaded!', 'success');
    }, 1500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-5 border border-purple-500/30 overflow-hidden relative"
        >
          {/* Top Banner Gradient */}
          <div className="absolute -right-12 -top-12 w-40 h-40 bg-gradient-to-tr from-purple-600/30 to-pink-500/30 rounded-full blur-2xl pointer-events-none" />

          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-500 to-pink-500 text-white flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Download className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h3 className="font-black text-lg text-gray-900 dark:text-white flex items-center gap-1.5">
                  Download MoneyFlow App 📲
                </h3>
                <p className="text-xs text-gray-400">Install on Android, iOS, Windows, or Mac</p>
              </div>
            </div>

            <button onClick={onClose} className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-gray-100 dark:hover:bg-white/10">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Platform Tabs */}
          <div className="flex p-1 bg-gray-100 dark:bg-black/40 rounded-2xl">
            <button
              onClick={() => setActiveTab('mobile')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'mobile' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-500'
              }`}
            >
              📱 Mobile PWA
            </button>
            <button
              onClick={() => setActiveTab('apk')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'apk' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-500'
              }`}
            >
              🤖 Android APK
            </button>
            <button
              onClick={() => setActiveTab('desktop')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'desktop' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-500'
              }`}
            >
              💻 Desktop App
            </button>
            <button
              onClick={() => setActiveTab('qr')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'qr' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-500'
              }`}
            >
              📷 Scan QR
            </button>
          </div>

          {/* Tab Content */}
          <div className="space-y-4 pt-1">
            {activeTab === 'mobile' && (
              <div className="space-y-3">
                <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/40 space-y-2">
                  <div className="flex items-center gap-2 text-purple-700 dark:text-purple-300 font-extrabold text-sm">
                    <Sparkles className="w-4 h-4 text-purple-500" /> Fast Progressive Web App (PWA)
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                    MoneyFlow can be installed directly onto your phone's home screen without using storage space. Works 100% offline!
                  </p>
                </div>

                <div className="space-y-2 text-xs text-gray-600 dark:text-gray-300 font-medium">
                  <p className="font-bold text-gray-900 dark:text-white">How to Install on Mobile:</p>
                  <div className="flex items-center gap-2 bg-gray-50 dark:bg-white/5 p-2.5 rounded-xl">
                    <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px] font-bold">1</span>
                    <span>Android Chrome: Tap <b>⋮ Menu</b> & select <b>"Add to Home Screen"</b></span>
                  </div>
                  <div className="flex items-center gap-2 bg-gray-50 dark:bg-white/5 p-2.5 rounded-xl">
                    <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px] font-bold">2</span>
                    <span>iOS Safari: Tap <b>Share Share</b> icon & select <b>"Add to Home Screen"</b></span>
                  </div>
                </div>

                <button
                  onClick={handleInstallPWA}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 text-white font-extrabold text-xs shadow-xl flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isInstalled ? 'App Installed on Home Screen ✅' : 'Install MoneyFlow App Now'}</span>
                </button>
              </div>
            )}

            {activeTab === 'apk' && (
              <div className="space-y-3">
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/40 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-extrabold text-sm">
                    <ShieldCheck className="w-4 h-4 text-emerald-500" /> Direct Android APK Package
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    Download the standalone MoneyFlow APK file for offline Android installation. Compatible with Android 8.0+.
                  </p>
                </div>

                <button
                  onClick={handleDownloadAPK}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-xs shadow-xl flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
                >
                  <Download className="w-4 h-4" />
                  <span>Download MoneyFlow_v1.0.0.apk (12.4 MB)</span>
                </button>
              </div>
            )}

            {activeTab === 'desktop' && (
              <div className="space-y-3">
                <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 space-y-2">
                  <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300 font-extrabold text-sm">
                    <Monitor className="w-4 h-4 text-blue-500" /> Desktop Client for Windows & Mac
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    Enjoy a full desktop experience with keyboard shortcuts, multi-window financial analytics, and automatic cloud backup sync.
                  </p>
                </div>

                <button
                  onClick={handleDownloadDesktop}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-extrabold text-xs shadow-xl flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
                >
                  <Download className="w-4 h-4" />
                  <span>Download MoneyFlow Setup (.exe / .dmg)</span>
                </button>
              </div>
            )}

            {activeTab === 'qr' && (
              <div className="p-6 rounded-2xl bg-gray-50 dark:bg-white/5 text-center space-y-3">
                <div className="w-36 h-36 mx-auto bg-white p-3 rounded-2xl shadow-md border flex items-center justify-center">
                  {/* Dynamic SVG QR Code mockup */}
                  <svg viewBox="0 0 100 100" className="w-full h-full text-purple-700 fill-current">
                    <path d="M0,0 h30 v30 h-30 z M10,10 h10 v10 h-10 z M70,0 h30 v30 h-30 z M80,10 h10 v10 h-10 z M0,70 h30 v30 h-30 z M10,80 h10 v10 h-10 z M40,10 h20 v10 h-20 z M10,40 h20 v20 h-20 z M40,40 h20 v20 h-20 z M70,40 h20 v20 h-20 z M40,70 h20 v20 h-20 z M70,70 h30 v30 h-30 z" />
                  </svg>
                </div>
                <p className="text-xs font-bold text-gray-800 dark:text-white">
                  Scan with your smartphone camera to open MoneyFlow instantly!
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
