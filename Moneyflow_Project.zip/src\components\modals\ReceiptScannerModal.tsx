import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryName } from '../../types';
import { Camera, Sparkles, CheckCircle2, X, Upload, ScanLine } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ReceiptScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptScannerModal: React.FC<ReceiptScannerModalProps> = ({ isOpen, onClose }) => {
  const { addTransaction, settings, triggerConfetti, showToast } = useApp();

  const [isScanning, setIsScanning] = useState(false);
  const [scannedData, setScannedData] = useState<{
    storeName: string;
    totalAmount: number;
    gstAmount: number;
    category: CategoryName;
    date: string;
  } | null>(null);

  const sampleReceipts = [
    { name: 'D-Mart Supermarket 🛒', amount: 1850, gst: 92, category: 'Shopping' as CategoryName },
    { name: 'Cafe Coffee Day ☕', amount: 420, gst: 21, category: 'Food' as CategoryName },
    { name: 'Shell Petrol Pump ⛽', amount: 1500, gst: 75, category: 'Fuel' as CategoryName },
    { name: 'Apollo Pharmacy 💊', amount: 680, gst: 34, category: 'Medicine' as CategoryName }
  ];

  const handleSimulateScan = (receipt: typeof sampleReceipts[0]) => {
    setIsScanning(true);
    setScannedData(null);

    setTimeout(() => {
      setIsScanning(false);
      setScannedData({
        storeName: receipt.name,
        totalAmount: receipt.amount,
        gstAmount: receipt.gst,
        category: receipt.category,
        date: new Date().toISOString().split('T')[0]
      });
      showToast('Receipt scanned successfully!', 'success');
    }, 1800);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleSimulateScan(sampleReceipts[0]);
    }
  };

  const handleSaveScannedReceipt = () => {
    if (!scannedData) return;

    addTransaction({
      type: 'expense',
      amount: scannedData.totalAmount,
      category: scannedData.category,
      description: `Receipt OCR: ${scannedData.storeName}`,
      date: scannedData.date,
      paymentMethod: 'Card',
      notes: `Scanned Receipt Total: ${settings.currency}${scannedData.totalAmount} (GST: ${settings.currency}${scannedData.gstAmount})`
    });

    triggerConfetti();
    setScannedData(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto border border-white/20"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-2xl bg-amber-500/10 text-amber-500">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                Live Receipt Scanner (OCR) 📷
              </h3>
              <p className="text-[11px] text-gray-400">Scan physical bill or receipt photo</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-xl text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Button */}
        <label className="p-6 rounded-3xl border-2 border-dashed border-purple-500/40 bg-purple-50/50 dark:bg-purple-950/20 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-purple-100/50 transition-all text-center">
          <Upload className="w-8 h-8 text-purple-600 dark:text-purple-400 animate-bounce" />
          <div>
            <span className="text-xs font-black text-purple-700 dark:text-purple-300 block">
              Take Photo or Upload Receipt Image
            </span>
            <span className="text-[10px] text-gray-400">Supports JPG, PNG, PDF receipts</span>
          </div>
          <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
        </label>

        {/* Preset Receipts for Demo */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Or Tap Sample Receipt to Scan:</span>
          <div className="grid grid-cols-2 gap-2">
            {sampleReceipts.map((rc, idx) => (
              <button
                key={idx}
                onClick={() => handleSimulateScan(rc)}
                className="p-2.5 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-left hover:border-purple-500 transition-all group"
              >
                <span className="text-xs font-bold text-gray-900 dark:text-white block group-hover:text-purple-500">
                  {rc.name}
                </span>
                <span className="text-[10px] font-extrabold text-purple-600 dark:text-purple-400">
                  {settings.currency}{rc.amount}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Laser Scanning Animation */}
        {isScanning && (
          <div className="p-6 rounded-3xl bg-slate-900 text-white flex flex-col items-center justify-center gap-3 relative overflow-hidden">
            <ScanLine className="w-10 h-10 text-emerald-400 animate-pulse" />
            <motion.div
              initial={{ y: -40 }}
              animate={{ y: 40 }}
              transition={{ repeat: Infinity, duration: 1, repeatType: 'reverse' }}
              className="w-full h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent absolute"
            />
            <span className="text-xs font-bold tracking-wider text-emerald-300">
              Scanning Receipt & Extracting Text...
            </span>
          </div>
        )}

        {/* Scanned Result Card */}
        {scannedData && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Sparkles className="w-4 h-4" /> Receipt Details Detected
              </span>
              <span className="bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                OCR Matched
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <div>
                <span className="text-gray-400 block text-[10px]">Store Name</span>
                <span className="text-xs font-extrabold text-gray-900 dark:text-white">{scannedData.storeName}</span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">Detected Total</span>
                <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                  {settings.currency}{scannedData.totalAmount.toLocaleString()}
                </span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">Category</span>
                <span className="text-xs font-bold text-purple-600 dark:text-purple-400">{scannedData.category}</span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">GST Included</span>
                <span className="text-xs font-bold text-gray-800 dark:text-gray-200">
                  {settings.currency}{scannedData.gstAmount}
                </span>
              </div>
            </div>

            <button
              onClick={handleSaveScannedReceipt}
              className="w-full py-3 rounded-xl bg-emerald-600 text-white font-extrabold text-xs shadow-md flex items-center justify-center gap-1.5 hover:bg-emerald-700 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" /> Log Scanned Receipt Entry
            </button>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};
