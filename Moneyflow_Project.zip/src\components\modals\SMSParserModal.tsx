import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryName, PaymentMethod } from '../../types';
import { MessageSquareCode, Sparkles, CheckCircle2, Copy, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface SMSParserModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SMSParserModal: React.FC<SMSParserModalProps> = ({ isOpen, onClose }) => {
  const { addTransaction, settings, triggerConfetti, showToast } = useApp();

  const [smsText, setSmsText] = useState('');
  const [parsedResult, setParsedResult] = useState<{
    amount: number;
    type: 'income' | 'expense';
    merchant: string;
    category: CategoryName;
    paymentMethod: PaymentMethod;
  } | null>(null);

  // Sample SMS presets for easy testing
  const sampleSMSList = [
    "Paid Rs.350 to Zomato via UPI ref 928374 on 06-Aug-2026. Available balance Rs 45200.",
    "Rs 500 debited from A/C XX8492 at SHELL PETROL PUMP via Debit Card on 06-Aug-2026.",
    "Salary of Rs 65000.00 credited to A/C XX4920 by TECHCORP PVT LTD on 01-Aug-2026.",
    "Rs 1800 debited for Jio Fiber Broadband recharge via NetBanking."
  ];

  const parseSMS = (text: string) => {
    if (!text.trim()) return;

    // 1. Detect Amount
    const amountMatch = text.match(/(?:Rs\.?|INR|\₹)\s*([\d,]+(?:\.\d{1,2})?)/i) || text.match(/([\d,]+(?:\.\d{1,2})?)\s*(?:Rs|INR|\₹)/i);
    const rawAmount = amountMatch ? amountMatch[1].replace(/,/g, '') : '0';
    const amount = parseFloat(rawAmount) || 0;

    // 2. Detect Type (Income vs Expense)
    const isIncome = /credited|received|salary|deposited|added/i.test(text);
    const type: 'income' | 'expense' = isIncome ? 'income' : 'expense';

    // 3. Detect Payment Method
    let paymentMethod: PaymentMethod = 'UPI';
    if (/card|debit|credit/i.test(text)) paymentMethod = 'Card';
    else if (/netbanking|neft|rtgs|imps/i.test(text)) paymentMethod = 'NetBanking';
    else if (/cash/i.test(text)) paymentMethod = 'Cash';

    // 4. Detect Category & Merchant
    let category: CategoryName = 'Others';
    let merchant = isIncome ? 'Income Source' : 'Merchant';

    if (/zomato|swiggy|restaurant|food|cafe|mcdonald/i.test(text)) {
      category = 'Food';
      merchant = 'Zomato / Food';
    } else if (/petrol|fuel|shell|hpcl|bpcl/i.test(text)) {
      category = 'Fuel';
      merchant = 'Shell Fuel Pump';
    } else if (/recharge|jio|airtel|broadband|wifi/i.test(text)) {
      category = 'Recharge';
      merchant = 'Recharge / Wifi';
    } else if (/salary|techcorp|company/i.test(text)) {
      category = 'Salary';
      merchant = 'Salary Employer';
    } else if (/amazon|flipkart|myntra|shopping|mall/i.test(text)) {
      category = 'Shopping';
      merchant = 'Online Shopping';
    }

    setParsedResult({
      amount,
      type,
      merchant,
      category,
      paymentMethod
    });
  };

  const handleSaveParsedTransaction = () => {
    if (!parsedResult || parsedResult.amount <= 0) {
      showToast('No valid amount parsed from SMS', 'error');
      return;
    }

    addTransaction({
      type: parsedResult.type,
      amount: parsedResult.amount,
      category: parsedResult.category,
      description: `Parsed: ${parsedResult.merchant}`,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: parsedResult.paymentMethod,
      notes: `Auto-parsed from Banking SMS`
    });

    triggerConfetti();
    setSmsText('');
    setParsedResult(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto border border-white/20"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <MessageSquareCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                Bank SMS Auto-Parser 📲
              </h3>
              <p className="text-[11px] text-gray-400">Paste bank/UPI SMS to log entry in 1-tap</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-xl text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sample SMS Presets */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Tap Sample SMS to Test:</span>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
            {sampleSMSList.map((sample, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSmsText(sample);
                  parseSMS(sample);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/40 text-[10px] font-bold text-purple-700 dark:text-purple-300 shrink-0 hover:bg-purple-100 transition-all"
              >
                Sample #{idx + 1}
              </button>
            ))}
          </div>
        </div>

        {/* Text Area */}
        <div className="space-y-2">
          <textarea
            rows={3}
            placeholder="Paste your bank or UPI transaction SMS here..."
            value={smsText}
            onChange={e => {
              setSmsText(e.target.value);
              parseSMS(e.target.value);
            }}
            className="w-full p-3.5 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Parsed Result Card */}
        {parsedResult && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-2xl bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-pink-500/10 border border-purple-500/30 space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-purple-600 dark:text-purple-400 flex items-center gap-1">
                <Sparkles className="w-4 h-4" /> Smart AI Extracted Entry
              </span>
              <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase ${
                parsedResult.type === 'income' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
              }`}>
                {parsedResult.type.toUpperCase()}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <div>
                <span className="text-gray-400 block text-[10px]">Detected Amount</span>
                <span className="text-lg font-black text-gray-900 dark:text-white">
                  {settings.currency}{parsedResult.amount.toLocaleString()}
                </span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">Merchant / Source</span>
                <span className="text-xs font-bold text-gray-800 dark:text-gray-200">{parsedResult.merchant}</span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">Category</span>
                <span className="text-xs font-bold text-purple-600 dark:text-purple-400">{parsedResult.category}</span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">Payment Method</span>
                <span className="text-xs font-bold text-gray-800 dark:text-gray-200">{parsedResult.paymentMethod}</span>
              </div>
            </div>

            <button
              onClick={handleSaveParsedTransaction}
              className="w-full py-3 rounded-xl bg-purple-600 text-white font-extrabold text-xs shadow-md flex items-center justify-center gap-1.5 hover:bg-purple-700 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" /> Save Parsed Entry to MoneyFlow
            </button>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};
