import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { CATEGORIES } from '../../constants/defaultData';
import { CategoryIcon } from '../common/CategoryIcon';
import { CategoryName, PaymentMethod, TransactionType } from '../../types';
import { X, Camera, Mic, Check, DollarSign, Calendar, FileText, Tag, CreditCard } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const TransactionModal: React.FC = () => {
  const { 
    isAddModalOpen, 
    closeAddModal, 
    addModalType, 
    editingTransaction, 
    addTransaction, 
    updateTransaction,
    settings,
    showToast 
  } = useApp();

  const [type, setType] = useState<TransactionType>(addModalType);
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState<CategoryName>('Food');
  const [description, setDescription] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [notes, setNotes] = useState<string>('');
  const [billPhoto, setBillPhoto] = useState<string | undefined>(undefined);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);

  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAmount(editingTransaction.amount.toString());
      setCategory(editingTransaction.category);
      setDescription(editingTransaction.description);
      setDate(editingTransaction.date);
      setPaymentMethod(editingTransaction.paymentMethod);
      setNotes(editingTransaction.notes || '');
      setBillPhoto(editingTransaction.billPhoto);
    } else {
      setType(addModalType);
      setAmount('');
      setCategory(addModalType === 'income' ? 'Salary' : 'Food');
      setDescription('');
      setDate(new Date().toISOString().split('T')[0]);
      setPaymentMethod('UPI');
      setNotes('');
      setBillPhoto(undefined);
    }
  }, [editingTransaction, addModalType, isAddModalOpen]);

  if (!isAddModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      showToast('Please enter a valid amount', 'error');
      return;
    }

    if (editingTransaction) {
      updateTransaction({
        ...editingTransaction,
        type,
        amount: numAmount,
        category,
        description: description || category,
        date,
        paymentMethod,
        notes,
        billPhoto
      });
    } else {
      addTransaction({
        type,
        amount: numAmount,
        category,
        description: description || category,
        date,
        paymentMethod,
        notes,
        billPhoto
      });
    }
    closeAddModal();
  };

  // Voice expense simulator
  const handleVoiceInput = () => {
    setIsRecordingVoice(true);
    showToast('Listening... Speak expense details like "Spent 450 on Food"', 'info');
    setTimeout(() => {
      setIsRecordingVoice(false);
      setAmount('450');
      setCategory('Food');
      setDescription('Dinner with friends');
      showToast('Voice parsed: 450 for Food!', 'success');
    }, 2500);
  };

  // Photo upload simulator
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBillPhoto(reader.result as string);
        // Simulate OCR detection!
        if (!amount) setAmount('1250');
        showToast('Receipt scanned! Detected amount ₹1,250', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const filteredCategories = CATEGORIES.filter(
    c => c.type === type || c.type === 'both'
  );

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ y: '100%', opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '100%', opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border border-white/20 dark:border-white/10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-4 border-b border-gray-100 dark:border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-xl text-white ${type === 'expense' ? 'bg-rose-500' : 'bg-emerald-500'}`}>
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-gray-800 dark:text-white">
                  {editingTransaction ? 'Edit Transaction' : type === 'expense' ? 'Add Expense' : 'Add Income'}
                </h3>
                <p className="text-[11px] text-gray-400">
                  {type === 'expense' ? 'Log your daily spending' : 'Log your incoming funds'}
                </p>
              </div>
            </div>

            <button
              onClick={closeAddModal}
              className="p-2 rounded-xl text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
            {/* Income / Expense Switcher */}
            <div className="flex p-1 bg-gray-100 dark:bg-black/40 rounded-2xl">
              <button
                type="button"
                onClick={() => setType('expense')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  type === 'expense'
                    ? 'bg-rose-500 text-white shadow-md'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
                }`}
              >
                Expense 🔴
              </button>
              <button
                type="button"
                onClick={() => setType('income')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  type === 'income'
                    ? 'bg-emerald-500 text-white shadow-md'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
                }`}
              >
                Income 🟢
              </button>
            </div>

            {/* Main Big Amount Field */}
            <div className="p-4 rounded-3xl bg-gray-50 dark:bg-black/30 border border-gray-200 dark:border-white/10 text-center relative">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest block mb-1">
                Enter Amount
              </span>
              <div className="flex items-center justify-center gap-1">
                <span className="text-3xl font-extrabold text-purple-600 dark:text-purple-400">
                  {settings.currency}
                </span>
                <input
                  type="number"
                  step="any"
                  placeholder="0.00"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  className="w-full max-w-[200px] text-3xl font-black bg-transparent text-center focus:outline-none text-gray-900 dark:text-white"
                  autoFocus
                />
              </div>

              {/* Quick Assistant Controls: Voice & Photo */}
              <div className="flex items-center justify-center gap-3 mt-3 pt-3 border-t border-gray-200/50 dark:border-white/5">
                <button
                  type="button"
                  onClick={handleVoiceInput}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    isRecordingVoice
                      ? 'bg-rose-500 text-white animate-pulse'
                      : 'bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-300'
                  }`}
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>{isRecordingVoice ? 'Recording...' : 'Voice Entry'}</span>
                </button>

                <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-300 text-xs font-semibold cursor-pointer hover:opacity-90">
                  <Camera className="w-3.5 h-3.5" />
                  <span>Scan Receipt</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {billPhoto && (
                <div className="mt-2 relative inline-block">
                  <img src={billPhoto} alt="Bill receipt" className="w-16 h-16 object-cover rounded-xl border-2 border-purple-500" />
                  <button
                    type="button"
                    onClick={() => setBillPhoto(undefined)}
                    className="absolute -top-2 -right-2 bg-rose-500 text-white p-0.5 rounded-full"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            {/* Category Selector Grid */}
            <div>
              <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 block flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5" /> Select Category
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-44 overflow-y-auto p-1">
                {filteredCategories.map(cat => {
                  const isSelected = category === cat.name;
                  return (
                    <button
                      key={cat.name}
                      type="button"
                      onClick={() => setCategory(cat.name)}
                      className={`p-2.5 rounded-2xl flex flex-col items-center gap-1 transition-all ${
                        isSelected
                          ? 'bg-purple-600 text-white shadow-md scale-105 ring-2 ring-purple-400'
                          : 'bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-white/10'
                      }`}
                    >
                      <CategoryIcon category={cat.name} size={18} className={isSelected ? 'bg-white/20 text-white' : ''} />
                      <span className="text-[10px] font-bold tracking-tight truncate w-full text-center">
                        {cat.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Description & Payment Method */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1 block flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" /> Title / Merchant
                </label>
                <input
                  type="text"
                  placeholder="e.g. Starbuck Coffee, D-Mart"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1 block flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5" /> Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
                >
                  <option value="UPI">UPI (PhonePe / GPay)</option>
                  <option value="Cash">Cash</option>
                  <option value="Card">Debit / Credit Card</option>
                  <option value="NetBanking">NetBanking</option>
                </select>
              </div>
            </div>

            {/* Date & Notes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1 block flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" /> Transaction Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1 block">
                  Additional Notes
                </label>
                <input
                  type="text"
                  placeholder="Optional tags or notes"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            {/* Save Floating Action Button */}
            <div className="pt-2">
              <button
                type="submit"
                className={`w-full py-4 rounded-2xl text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-95 ${
                  type === 'expense' 
                    ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 shadow-rose-500/30' 
                    : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 shadow-emerald-500/30'
                }`}
              >
                <Check className="w-5 h-5 stroke-[3]" />
                <span>{editingTransaction ? 'Update Transaction' : 'Save Transaction'}</span>
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
