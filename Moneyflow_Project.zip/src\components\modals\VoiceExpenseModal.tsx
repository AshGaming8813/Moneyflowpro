import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryName, PaymentMethod } from '../../types';
import { Mic, MicOff, Sparkles, CheckCircle2, X } from 'lucide-react';
import { motion } from 'framer-motion';

interface VoiceExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoiceExpenseModal: React.FC<VoiceExpenseModalProps> = ({ isOpen, onClose }) => {
  const { addTransaction, settings, triggerConfetti, showToast } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [parsedData, setParsedData] = useState<{
    amount: number;
    type: 'income' | 'expense';
    category: CategoryName;
    paymentMethod: PaymentMethod;
    description: string;
  } | null>(null);

  const voicePresets = [
    "Spent 250 rupees on food at Zomato",
    "Spent 500 rupees on petrol via UPI",
    "Received 15000 rupees salary for freelancing",
    "Spent 1200 rupees on medicine"
  ];

  const processVoiceText = (text: string) => {
    setTranscript(text);

    // Extract numbers
    const matchAmount = text.match(/\b\d+\b/);
    const amount = matchAmount ? parseFloat(matchAmount[0]) : 0;

    const isIncome = /received|earned|got|salary|income|credited/i.test(text);
    const type: 'income' | 'expense' = isIncome ? 'income' : 'expense';

    let category: CategoryName = 'Others';
    if (/food|zomato|swiggy|dinner|lunch|tea/i.test(text)) category = 'Food';
    else if (/petrol|fuel|diesel/i.test(text)) category = 'Fuel';
    else if (/medicine|doctor|pharmacy/i.test(text)) category = 'Medicine';
    else if (/salary|freelance|client/i.test(text)) category = 'Salary';
    else if (/shopping|clothes|shoes/i.test(text)) category = 'Shopping';

    let paymentMethod: PaymentMethod = 'UPI';
    if (/cash/i.test(text)) paymentMethod = 'Cash';
    else if (/card/i.test(text)) paymentMethod = 'Card';
    else if (/bank/i.test(text)) paymentMethod = 'NetBanking';

    setParsedData({
      amount,
      type,
      category,
      paymentMethod,
      description: `Voice: ${text}`
    });
  };

  const handleStartMic = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      try {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.lang = settings.language === 'hi' ? 'hi-IN' : 'en-US';
        recognition.start();
        setIsListening(true);

        recognition.onresult = (event: any) => {
          const spoken = event.results[0][0].transcript;
          setIsListening(false);
          processVoiceText(spoken);
        };

        recognition.onerror = () => {
          setIsListening(false);
          showToast('Voice mic error. Try selecting a preset!', 'error');
        };
      } catch {
        setIsListening(false);
        showToast('Speech recognition not supported in browser. Select sample voice preset!', 'info');
      }
    } else {
      setIsListening(true);
      setTimeout(() => {
        setIsListening(false);
        processVoiceText(voicePresets[0]);
      }, 1500);
    }
  };

  const handleSaveVoiceEntry = () => {
    if (!parsedData || parsedData.amount <= 0) {
      showToast('No valid amount found in voice entry', 'error');
      return;
    }

    addTransaction({
      type: parsedData.type,
      amount: parsedData.amount,
      category: parsedData.category,
      description: parsedData.description,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: parsedData.paymentMethod,
      notes: 'Voice AI Entry'
    });

    triggerConfetti();
    setTranscript('');
    setParsedData(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto border border-white/20 text-center"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
            Voice AI Entry 🎤
          </h3>
          <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-gray-400">
          Tap the mic and speak natural commands like <br />
          <span className="font-bold text-purple-500">"Spent 250 rupees on food"</span>
        </p>

        {/* Big Mic Button */}
        <div className="flex justify-center py-4">
          <button
            onClick={handleStartMic}
            className={`w-24 h-24 rounded-full flex items-center justify-center text-white shadow-2xl transition-all ${
              isListening
                ? 'bg-rose-500 animate-ping ring-8 ring-rose-300'
                : 'bg-gradient-to-tr from-purple-600 to-pink-500 hover:scale-105 shadow-purple-500/40'
            }`}
          >
            {isListening ? <MicOff className="w-10 h-10" /> : <Mic className="w-10 h-10" />}
          </button>
        </div>

        {/* Sample Voice Presets */}
        <div className="space-y-1.5 text-left">
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Or Tap Sample Spoken Command:</span>
          <div className="space-y-1.5">
            {voicePresets.map((vp, idx) => (
              <button
                key={idx}
                onClick={() => processVoiceText(vp)}
                className="w-full p-2.5 rounded-2xl bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-bold text-gray-800 dark:text-gray-200 text-left hover:border-purple-500 transition-all flex items-center justify-between"
              >
                <span>🗣️ "{vp}"</span>
                <span className="text-[10px] text-purple-500 font-extrabold">Parse</span>
              </button>
            ))}
          </div>
        </div>

        {/* Parsed Result */}
        {parsedData && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-left space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-purple-600 dark:text-purple-400 flex items-center gap-1">
                <Sparkles className="w-4 h-4" /> Parsed Voice Command
              </span>
              <span className="bg-purple-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                {parsedData.type.toUpperCase()}
              </span>
            </div>

            <p className="text-xs italic text-gray-400">"{transcript}"</p>

            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <div>
                <span className="text-gray-400 block text-[10px]">Amount</span>
                <span className="text-base font-black text-gray-900 dark:text-white">
                  {settings.currency}{parsedData.amount}
                </span>
              </div>

              <div>
                <span className="text-gray-400 block text-[10px]">Category</span>
                <span className="text-xs font-bold text-purple-600 dark:text-purple-400">{parsedData.category}</span>
              </div>
            </div>

            <button
              onClick={handleSaveVoiceEntry}
              className="w-full py-3 rounded-xl bg-purple-600 text-white font-extrabold text-xs shadow-md flex items-center justify-center gap-1.5 hover:bg-purple-700 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" /> Save Voice Entry
            </button>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};
