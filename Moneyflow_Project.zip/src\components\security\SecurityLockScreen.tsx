import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, Fingerprint, Delete } from 'lucide-react';
import { motion } from 'framer-motion';

export const SecurityLockScreen: React.FC = () => {
  const { isLocked, unlockApp, settings } = useApp();
  const [pin, setPin] = useState('');

  if (!isLocked) return null;

  const handleKeyPress = (num: string) => {
    if (pin.length < 4) {
      const nextPin = pin + num;
      setPin(nextPin);
      if (nextPin.length === 4) {
        setTimeout(() => {
          const success = unlockApp(nextPin);
          if (!success) setPin('');
        }, 150);
      }
    }
  };

  const handleDelete = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleBiometricUnlock = () => {
    unlockApp('1234');
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#121212] text-white flex flex-col items-center justify-center p-6 space-y-8 animate-fadeIn">
      {/* Top Shield Icon */}
      <div className="flex flex-col items-center space-y-3">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center shadow-xl shadow-purple-500/30">
          <Shield className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-2xl font-black tracking-tight">MoneyFlow Lock</h2>
        <p className="text-xs text-gray-400 font-medium">Enter your 4-digit PIN (Default: 1234)</p>
      </div>

      {/* PIN Dots Display */}
      <div className="flex items-center gap-4">
        {[0, 1, 2, 3].map(i => (
          <div
            key={i}
            className={`w-4 h-4 rounded-full transition-all ${
              i < pin.length ? 'bg-purple-500 scale-125 shadow-glow-purple' : 'bg-gray-800 border border-gray-700'
            }`}
          />
        ))}
      </div>

      {/* Keypad */}
      <div className="grid grid-cols-3 gap-5 max-w-xs w-full">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
          <motion.button
            key={num}
            whileTap={{ scale: 0.9 }}
            onClick={() => handleKeyPress(num)}
            className="w-16 h-16 rounded-full bg-white/5 hover:bg-white/10 text-xl font-bold border border-white/10 flex items-center justify-center mx-auto"
          >
            {num}
          </motion.button>
        ))}

        {/* Biometric button */}
        {settings.biometricEnabled ? (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleBiometricUnlock}
            className="w-16 h-16 rounded-full bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 border border-purple-500/30 flex items-center justify-center mx-auto"
            title="Biometric Fingerprint"
          >
            <Fingerprint className="w-7 h-7" />
          </motion.button>
        ) : (
          <div className="w-16 h-16" />
        )}

        {/* 0 */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => handleKeyPress('0')}
          className="w-16 h-16 rounded-full bg-white/5 hover:bg-white/10 text-xl font-bold border border-white/10 flex items-center justify-center mx-auto"
        >
          0
        </motion.button>

        {/* Backspace */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleDelete}
          className="w-16 h-16 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 flex items-center justify-center mx-auto"
        >
          <Delete className="w-6 h-6" />
        </motion.button>
      </div>
    </div>
  );
};
