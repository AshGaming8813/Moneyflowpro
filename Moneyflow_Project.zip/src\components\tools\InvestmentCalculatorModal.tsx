import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrendingUp, Calculator, X, Sparkles, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface InvestmentCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InvestmentCalculatorModal: React.FC<InvestmentCalculatorModalProps> = ({ isOpen, onClose }) => {
  const { settings } = useApp();

  const [monthlyAmount, setMonthlyAmount] = useState('5000');
  const [returnRate, setReturnRate] = useState('12');
  const [tenureYears, setTenureYears] = useState('5');

  if (!isOpen) return null;

  const P = parseFloat(monthlyAmount) || 0;
  const i = (parseFloat(returnRate) || 0) / 12 / 100;
  const n = (parseFloat(tenureYears) || 0) * 12;

  // SIP Formula: M = P × ({[1 + i]^n - 1} / i) × (1 + i)
  let totalValue = 0;
  if (i > 0 && n > 0 && P > 0) {
    totalValue = Math.round(P * ((Math.pow(1 + i, n) - 1) / i) * (1 + i));
  } else {
    totalValue = P * n;
  }

  const totalInvested = Math.round(P * n);
  const totalReturns = Math.max(0, totalValue - totalInvested);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4 border border-white/20 dark:border-white/10"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-emerald-500 text-white shadow-md">
                <Calculator className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                  SIP Investment Calculator 📈
                </h3>
                <p className="text-[11px] text-gray-400">Calculate future wealth growth</p>
              </div>
            </div>

            <button onClick={onClose} className="p-2 rounded-xl text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-gray-400 uppercase">Monthly SIP Investment ({settings.currency})</label>
              <input
                type="number"
                value={monthlyAmount}
                onChange={e => setMonthlyAmount(e.target.value)}
                className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase">Expected Rate (%)</label>
                <input
                  type="number"
                  value={returnRate}
                  onChange={e => setReturnRate(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-400 uppercase">Tenure (Years)</label>
                <input
                  type="number"
                  value={tenureYears}
                  onChange={e => setTenureYears(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>
          </div>

          {/* Results Summary Box */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-900 via-indigo-900 to-slate-900 text-white space-y-2 border border-purple-500/30">
            <span className="text-[10px] font-bold uppercase text-purple-200">Expected Total Wealth Value</span>
            <p className="text-3xl font-black text-emerald-400">
              {settings.currency}{totalValue.toLocaleString()}
            </p>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10 text-xs">
              <div>
                <span className="text-gray-400 text-[10px] uppercase block">Total Invested</span>
                <span className="font-bold">{settings.currency}{totalInvested.toLocaleString()}</span>
              </div>
              <div className="text-right">
                <span className="text-gray-400 text-[10px] uppercase block">Est. Growth Gain</span>
                <span className="font-bold text-emerald-300">+{settings.currency}{totalReturns.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
