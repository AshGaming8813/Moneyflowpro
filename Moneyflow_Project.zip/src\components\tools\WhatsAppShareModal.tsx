import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Share2, MessageCircle, Copy, CheckCircle2, X } from 'lucide-react';
import { motion } from 'framer-motion';

interface WhatsAppShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppShareModal: React.FC<WhatsAppShareModalProps> = ({ isOpen, onClose }) => {
  const { currentBalance, totalIncome, totalExpense, settings, showToast } = useApp();

  const shareText = `💰 *MoneyFlow Financial Summary* (${settings.userName})
📅 Date: ${new Date().toLocaleDateString()}
------------------------------
💵 Total Income: ${settings.currency}${totalIncome.toLocaleString()}
💸 Total Expenses: ${settings.currency}${totalExpense.toLocaleString()}
🏦 Current Balance: ${settings.currency}${currentBalance.toLocaleString()}
------------------------------
📲 Sent via MoneyFlow App`;

  const handleShareWhatsApp = () => {
    const encodedText = encodeURIComponent(shareText);
    window.open(`https://wa.me/?text=${encodedText}`, '_blank');
    showToast('Opening WhatsApp to share statement!', 'success');
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(shareText);
    showToast('Formatted statement copied to clipboard!', 'success');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4 border border-white/20"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-2xl bg-emerald-500/10 text-emerald-500">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                Share Statement on WhatsApp 📲
              </h3>
              <p className="text-[11px] text-gray-400">1-Tap share financial summary with contacts</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Text Preview Box */}
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 text-xs font-mono whitespace-pre-wrap text-emerald-950 dark:text-emerald-200">
          {shareText}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleShareWhatsApp}
            className="py-3.5 rounded-2xl bg-emerald-600 text-white font-extrabold text-xs shadow-lg flex items-center justify-center gap-2 hover:bg-emerald-700 transition-all"
          >
            <MessageCircle className="w-4 h-4 fill-white" /> Share on WhatsApp
          </button>

          <button
            onClick={handleCopyText}
            className="py-3.5 rounded-2xl bg-gray-100 dark:bg-white/10 text-gray-800 dark:text-white font-extrabold text-xs shadow-xs flex items-center justify-center gap-2 hover:bg-gray-200 transition-all"
          >
            <Copy className="w-4 h-4" /> Copy Text
          </button>
        </div>
      </motion.div>
    </div>
  );
};
