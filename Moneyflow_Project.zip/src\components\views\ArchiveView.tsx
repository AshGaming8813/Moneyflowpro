import React from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryIcon } from '../common/CategoryIcon';
import { Archive, RotateCcw, Trash2 } from 'lucide-react';

export const ArchiveView: React.FC = () => {
  const { transactions, restoreTransaction, deleteTransaction, settings } = useApp();

  const archivedTx = transactions.filter(t => t.isArchived);

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      <div>
        <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
          Archived Transactions 📦
        </h2>
        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
          Safely archived transactions can be restored anytime
        </p>
      </div>

      <div className="space-y-3">
        {archivedTx.length === 0 ? (
          <div className="p-10 text-center glass-card rounded-3xl space-y-2">
            <Archive className="w-10 h-10 text-gray-400 mx-auto" />
            <h4 className="font-bold text-gray-800 dark:text-white">Archive is Empty</h4>
            <p className="text-xs text-gray-400">Transactions you archive will appear here instead of being permanently deleted.</p>
          </div>
        ) : (
          archivedTx.map(tx => (
            <div key={tx.id} className="p-4 rounded-3xl glass-card flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CategoryIcon category={tx.category} size={22} />
                <div>
                  <h4 className="font-bold text-sm text-gray-800 dark:text-gray-100">{tx.description}</h4>
                  <span className="text-[11px] text-gray-400">{tx.date} • {tx.paymentMethod}</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className={`text-base font-extrabold ${tx.type === 'income' ? 'text-emerald-500' : 'text-rose-500'}`}>
                  {settings.currency}{tx.amount.toLocaleString()}
                </span>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => restoreTransaction(tx.id)}
                    className="p-2 rounded-xl bg-purple-100 text-purple-600 dark:bg-purple-950/60 dark:text-purple-300 font-bold text-xs flex items-center gap-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Restore
                  </button>
                  <button
                    onClick={() => deleteTransaction(tx.id)}
                    className="p-2 rounded-xl text-rose-500 hover:bg-rose-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
