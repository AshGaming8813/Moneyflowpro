import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BillCategory } from '../../types';
import { Receipt, Plus, CheckCircle2, Clock, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const BillsView: React.FC = () => {
  const { bills, settings, addBill, payBill, deleteBill, showToast, t } = useApp();

  const [isAddBillOpen, setIsAddBillOpen] = useState(false);
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [category, setCategory] = useState<BillCategory>('Electricity');

  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    const billAmt = parseFloat(amount);
    if (!name || !billAmt || billAmt <= 0) {
      showToast('Please enter bill name and amount', 'error');
      return;
    }

    addBill({
      name,
      amount: billAmt,
      dueDate: dueDate || new Date().toISOString().split('T')[0],
      category,
      reminderTime: '09:00',
      repeat: 'Monthly',
      autoNotify: true
    });

    setIsAddBillOpen(false);
    setName('');
    setAmount('');
  };

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
            {t('billsTitle')}
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
            Never miss an electricity, internet or OTT subscription bill
          </p>
        </div>

        <button
          onClick={() => setIsAddBillOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-extrabold shadow-lg hover:opacity-90 transition-all"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Bill</span>
        </button>
      </div>

      {/* Bills List */}
      <div className="space-y-4">
        {bills.length === 0 ? (
          <div className="p-10 text-center glass-card rounded-3xl space-y-2">
            <Receipt className="w-12 h-12 text-amber-500 mx-auto" />
            <h4 className="font-bold text-gray-800 dark:text-white">No Upcoming Bills</h4>
            <p className="text-xs text-gray-400">Add recurring bills to receive automated payment reminders!</p>
          </div>
        ) : (
          bills.map(bill => (
            <motion.div
              key={bill.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-5 rounded-3xl glass-card space-y-4 relative overflow-hidden group border border-white/30 dark:border-white/10 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md">
                  <Receipt className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
                    {bill.name}
                    {bill.isPaid && (
                      <span className="bg-emerald-100 text-emerald-600 text-[10px] px-2 py-0.5 rounded-full font-bold">
                        Paid ✅
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-gray-400 font-medium flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3 text-amber-500" /> Due Date: {bill.dueDate}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <span className="text-base font-black text-gray-900 dark:text-white block">
                    {settings.currency}{bill.amount.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-gray-400 font-semibold">{bill.repeat}</span>
                </div>

                {!bill.isPaid ? (
                  <button
                    onClick={() => payBill(bill.id)}
                    className="px-4 py-2 rounded-2xl bg-amber-500 text-white font-extrabold text-xs shadow-md hover:bg-amber-600 transition-all flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Pay Now
                  </button>
                ) : (
                  <button
                    onClick={() => deleteBill(bill.id)}
                    className="p-2 rounded-xl text-gray-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Add Bill Modal */}
      <AnimatePresence>
        {isAddBillOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                  Add Bill Reminder 🧾
                </h3>
                <button onClick={() => setIsAddBillOpen(false)}>
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <form onSubmit={handleCreateBill} className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Bill Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Electricity Bill, Wifi Broadband"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Amount ({settings.currency})</label>
                  <input
                    type="number"
                    placeholder="e.g. 2450"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Due Date</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-amber-500 text-white font-extrabold text-xs shadow-lg"
                >
                  Save Bill Reminder
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
