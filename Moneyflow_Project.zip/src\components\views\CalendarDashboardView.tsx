import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryIcon } from '../common/CategoryIcon';
import { Transaction } from '../../types';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, TrendingDown, Award, Zap, DollarSign, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const CalendarDashboardView: React.FC = () => {
  const { transactions, settings, totalIncome, totalExpense } = useApp();
  
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDayTx, setSelectedDayTx] = useState<Transaction[] | null>(null);
  const [selectedDayStr, setSelectedDayStr] = useState<string>('');

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayIndex = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleDayClick = (dayNum: number) => {
    const monthStr = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const dayStr = dayNum.toString().padStart(2, '0');
    const dateFormatted = `${currentDate.getFullYear()}-${monthStr}-${dayStr}`;
    
    const dayTxs = transactions.filter(t => t.date === dateFormatted);
    setSelectedDayStr(dateFormatted);
    setSelectedDayTx(dayTxs);
  };

  // Metrics
  const avgDailySpending = Math.round(totalExpense / 30);

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Title */}
      <div>
        <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
          Calendar & Analytics 📅
        </h2>
        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
          Interactive daily timeline and financial dashboard
        </p>
      </div>

      {/* Analytics Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl glass-card border border-white/20">
          <span className="text-[10px] font-bold text-gray-400 uppercase">Avg Daily Spend</span>
          <p className="text-lg font-black text-rose-500 mt-1">
            {settings.currency}{avgDailySpending.toLocaleString()}
          </p>
        </div>

        <div className="p-4 rounded-3xl glass-card border border-white/20">
          <span className="text-[10px] font-bold text-gray-400 uppercase">Total Entries</span>
          <p className="text-lg font-black text-purple-600 dark:text-purple-400 mt-1">
            {transactions.length} Logs
          </p>
        </div>

        <div className="p-4 rounded-3xl glass-card border border-white/20">
          <span className="text-[10px] font-bold text-gray-400 uppercase">Top Category</span>
          <p className="text-lg font-black text-emerald-500 mt-1 truncate">
            Food
          </p>
        </div>

        <div className="p-4 rounded-3xl glass-card border border-white/20">
          <span className="text-[10px] font-bold text-gray-400 uppercase">Savings Ratio</span>
          <p className="text-lg font-black text-blue-500 mt-1">
            83%
          </p>
        </div>
      </div>

      {/* Monthly Calendar View */}
      <div className="p-5 rounded-3xl glass-card space-y-4">
        {/* Calendar Header Switcher */}
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-purple-600" />
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>

          <div className="flex items-center gap-1">
            <button
              onClick={handlePrevMonth}
              className="p-2 rounded-xl hover:bg-gray-200 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNextMonth}
              className="p-2 rounded-xl hover:bg-gray-200 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 text-center text-xs font-bold text-gray-400">
          <span>Sun</span>
          <span>Mon</span>
          <span>Tue</span>
          <span>Wed</span>
          <span>Thu</span>
          <span>Fri</span>
          <span>Sat</span>
        </div>

        {/* Grid Days */}
        <div className="grid grid-cols-7 gap-1.5 pt-2">
          {/* Empty slots for start of month */}
          {Array.from({ length: firstDayIndex }).map((_, idx) => (
            <div key={`empty-${idx}`} className="h-10 sm:h-12" />
          ))}

          {/* Days */}
          {Array.from({ length: daysInMonth }).map((_, idx) => {
            const dayNum = idx + 1;
            const monthStr = (currentDate.getMonth() + 1).toString().padStart(2, '0');
            const dayStr = dayNum.toString().padStart(2, '0');
            const dateFormatted = `${currentDate.getFullYear()}-${monthStr}-${dayStr}`;

            const dayTxs = transactions.filter(t => t.date === dateFormatted);
            const hasTx = dayTxs.length > 0;
            const hasIncome = dayTxs.some(t => t.type === 'income');
            const hasExpense = dayTxs.some(t => t.type === 'expense');

            return (
              <motion.button
                key={`day-${dayNum}`}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleDayClick(dayNum)}
                className={`h-10 sm:h-12 rounded-2xl flex flex-col items-center justify-center relative transition-all ${
                  hasTx
                    ? 'bg-purple-100 dark:bg-purple-950/60 font-bold border border-purple-300 dark:border-purple-800/40 text-purple-700 dark:text-purple-300 shadow-sm'
                    : 'hover:bg-gray-100 dark:hover:bg-white/5 text-gray-700 dark:text-gray-300'
                }`}
              >
                <span className="text-xs">{dayNum}</span>
                
                {/* Dot indicators */}
                {hasTx && (
                  <div className="flex gap-1 mt-0.5">
                    {hasIncome && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                    {hasExpense && <div className="w-1.5 h-1.5 rounded-full bg-rose-500" />}
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Transaction Drawer Popup */}
      <AnimatePresence>
        {selectedDayTx !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                    Logs for {selectedDayStr} 📅
                  </h3>
                  <p className="text-xs text-gray-400">{selectedDayTx.length} transaction(s) recorded</p>
                </div>
                <button onClick={() => setSelectedDayTx(null)}>
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <div className="max-h-64 overflow-y-auto space-y-2">
                {selectedDayTx.length === 0 ? (
                  <p className="text-center text-xs text-gray-400 py-6">No transactions recorded on this date.</p>
                ) : (
                  selectedDayTx.map(tx => (
                    <div key={tx.id} className="p-3 rounded-2xl bg-gray-50 dark:bg-white/5 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <CategoryIcon category={tx.category} size={20} />
                        <div>
                          <h4 className="font-bold text-xs text-gray-900 dark:text-white">{tx.description}</h4>
                          <span className="text-[10px] text-gray-400">{tx.paymentMethod}</span>
                        </div>
                      </div>
                      <span className={`font-black text-xs ${tx.type === 'income' ? 'text-emerald-500' : 'text-rose-500'}`}>
                        {tx.type === 'income' ? '+' : '-'}{settings.currency}{tx.amount}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
