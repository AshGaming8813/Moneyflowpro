import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Target, Plus, CheckCircle2, Trash2, Calendar, Sparkles, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const GoalsView: React.FC = () => {
  const { goals, settings, addGoal, depositGoal, deleteGoal, showToast, t } = useApp();

  const [isAddGoalOpen, setIsAddGoalOpen] = useState(false);
  const [depositGoalId, setDepositGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState('');

  // New Goal State
  const [title, setTitle] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [category, setCategory] = useState('Savings');
  const [deadline, setDeadline] = useState('');

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseFloat(targetAmount);
    if (!title || !target || target <= 0) {
      showToast('Please enter a goal name and target amount', 'error');
      return;
    }

    addGoal({
      title,
      targetAmount: target,
      currentAmount: 0,
      category,
      deadline,
      color: '#7C4DFF',
      icon: 'Target'
    });

    setIsAddGoalOpen(false);
    setTitle('');
    setTargetAmount('');
    setDeadline('');
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(depositAmount);
    if (depositGoalId && amount > 0) {
      depositGoal(depositGoalId, amount);
      setDepositGoalId(null);
      setDepositAmount('');
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
            {t('goalsTitle')}
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
            Save step-by-step for your dream car, house, bike or trip
          </p>
        </div>

        <button
          onClick={() => setIsAddGoalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-extrabold shadow-lg shadow-purple-500/30 hover:opacity-90 transition-all"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Goal</span>
        </button>
      </div>

      {/* Goals Grid */}
      <div className="space-y-4">
        {goals.length === 0 ? (
          <div className="p-10 text-center glass-card rounded-3xl space-y-2">
            <Target className="w-12 h-12 text-purple-400 mx-auto" />
            <h4 className="font-bold text-gray-800 dark:text-white">No Savings Goals Set</h4>
            <p className="text-xs text-gray-400">Create your first savings goal and deposit money towards it!</p>
          </div>
        ) : (
          goals.map(goal => {
            const percent = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));

            return (
              <motion.div
                key={goal.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 rounded-3xl glass-card space-y-4 relative overflow-hidden group border border-white/30 dark:border-white/10"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 text-white flex items-center justify-center shadow-md">
                      <Target className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
                        {goal.title}
                        {goal.completed && (
                          <span className="bg-emerald-100 text-emerald-600 text-[10px] px-2 py-0.5 rounded-full font-bold">
                            Achieved 🎉
                          </span>
                        )}
                      </h3>
                      <p className="text-xs text-gray-400 font-medium">
                        Target: {settings.currency}{goal.targetAmount.toLocaleString()} {goal.deadline && `• Due ${goal.deadline}`}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => deleteGoal(goal.id)}
                    className="p-2 rounded-xl text-gray-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-purple-600 dark:text-purple-400">
                      Saved: {settings.currency}{goal.currentAmount.toLocaleString()}
                    </span>
                    <span className="text-gray-500">{percent}%</span>
                  </div>
                  <div className="w-full h-3 bg-gray-200 dark:bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-600 via-pink-500 to-emerald-400 rounded-full transition-all duration-500"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                {/* Quick Deposit Action */}
                {!goal.completed && (
                  <button
                    onClick={() => setDepositGoalId(goal.id)}
                    className="w-full py-2.5 rounded-2xl bg-purple-600 text-white font-extrabold text-xs shadow-md hover:bg-purple-700 transition-all flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Deposit Savings
                  </button>
                )}
              </motion.div>
            );
          })
        )}
      </div>

      {/* Add Goal Modal */}
      <AnimatePresence>
        {isAddGoalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                  Create Savings Goal 🎯
                </h3>
                <button onClick={() => setIsAddGoalOpen(false)}>
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <form onSubmit={handleCreateGoal} className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Goal Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Buy Bike 🏍️, Vacation 🏖️"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Target Amount ({settings.currency})</label>
                  <input
                    type="number"
                    placeholder="e.g. 150000"
                    value={targetAmount}
                    onChange={e => setTargetAmount(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Target Date</label>
                  <input
                    type="date"
                    value={deadline}
                    onChange={e => setDeadline(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-extrabold text-xs shadow-lg"
                >
                  Create Savings Goal
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Deposit Modal */}
      <AnimatePresence>
        {depositGoalId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                  Deposit Savings 💰
                </h3>
                <button onClick={() => setDepositGoalId(null)}>
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <form onSubmit={handleDepositSubmit} className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Deposit Amount ({settings.currency})</label>
                  <input
                    type="number"
                    placeholder="e.g. 5000"
                    value={depositAmount}
                    onChange={e => setDepositAmount(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                    autoFocus
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-purple-600 text-white font-extrabold text-xs shadow-lg"
                >
                  Confirm Deposit
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
