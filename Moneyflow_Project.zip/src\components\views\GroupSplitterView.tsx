import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Users, Plus, CheckCircle2, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const GroupSplitterView: React.FC = () => {
  const { groupExpenses, addGroupExpense, settleGroupExpense, deleteGroupExpense, settings, showToast, t } = useApp();

  const [isAddGroupOpen, setIsAddGroupOpen] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [description, setDescription] = useState('');
  const [totalAmount, setTotalAmount] = useState('');
  const [paidBy, setPaidBy] = useState('Me');
  const [membersInput, setMembersInput] = useState('Me, Rahul, Priya, Amit');

  const handleCreateGroupExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(totalAmount);
    const memberList = membersInput.split(',').map(m => m.trim()).filter(Boolean);

    if (!groupName || !amount || amount <= 0 || memberList.length === 0) {
      showToast('Please fill out all group details', 'error');
      return;
    }

    const split = Math.round(amount / memberList.length);

    addGroupExpense({
      groupName,
      description: description || groupName,
      totalAmount: amount,
      paidBy: paidBy || settings.userName,
      members: memberList,
      splitAmountPerPerson: split
    });

    setIsAddGroupOpen(false);
    setGroupName('');
    setDescription('');
    setTotalAmount('');
  };

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
            {t('splitwiseTitle')}
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
            Split bills easily with friends, roommates & family
          </p>
        </div>

        <button
          onClick={() => setIsAddGroupOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-extrabold shadow-lg shadow-purple-500/30 hover:opacity-90 transition-all"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Split</span>
        </button>
      </div>

      {/* Groups List */}
      <div className="space-y-4">
        {groupExpenses.length === 0 ? (
          <div className="p-10 text-center glass-card rounded-3xl space-y-2">
            <Users className="w-12 h-12 text-purple-400 mx-auto" />
            <h4 className="font-bold text-gray-800 dark:text-white">No Shared Group Expenses</h4>
            <p className="text-xs text-gray-400">Add group expenses to calculate who owes what automatically.</p>
          </div>
        ) : (
          groupExpenses.map(grp => (
            <motion.div
              key={grp.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-5 rounded-3xl glass-card space-y-4 relative overflow-hidden group border border-white/30 dark:border-white/10"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-md">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
                      {grp.groupName}
                      {grp.isSettled && (
                        <span className="bg-emerald-100 text-emerald-600 text-[10px] px-2 py-0.5 rounded-full font-bold">
                          Settled ✅
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-gray-400 font-medium">
                      Paid by <span className="font-bold text-purple-600 dark:text-purple-400">{grp.paidBy}</span> ({grp.date})
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => deleteGroupExpense(grp.id)}
                  className="p-2 rounded-xl text-gray-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Amount Breakdown */}
              <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-white/5 flex items-center justify-between text-xs font-semibold">
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase">Total Bill</span>
                  <span className="text-gray-900 dark:text-white font-extrabold text-base">
                    {settings.currency}{grp.totalAmount.toLocaleString()}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-gray-400 block text-[10px] uppercase">Per Person Split ({grp.members.length} people)</span>
                  <span className="text-purple-600 dark:text-purple-400 font-extrabold text-base">
                    {settings.currency}{grp.splitAmountPerPerson.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Members status */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-gray-400 uppercase">Settlement Balance:</span>
                <div className="flex flex-wrap gap-2 pt-1">
                  {grp.members.map(member => {
                    const isPayer = member === grp.paidBy;
                    return (
                      <span
                        key={member}
                        className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${
                          isPayer
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                            : 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300'
                        }`}
                      >
                        {isPayer ? `${member} receives ${settings.currency}${grp.totalAmount - grp.splitAmountPerPerson}` : `${member} owes ${settings.currency}${grp.splitAmountPerPerson}`}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Action */}
              {!grp.isSettled && (
                <div className="pt-2">
                  <button
                    onClick={() => settleGroupExpense(grp.id)}
                    className="w-full py-2.5 rounded-2xl bg-emerald-500 text-white font-extrabold text-xs shadow-md hover:bg-emerald-600 transition-all flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Settle Up Group Balance</span>
                  </button>
                </div>
              )}
            </motion.div>
          ))
        )}
      </div>

      {/* Add Split Modal */}
      <AnimatePresence>
        {isAddGroupOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                  Add Split Expense 👥
                </h3>
                <button onClick={() => setIsAddGroupOpen(false)}>
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <form onSubmit={handleCreateGroupExpense} className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Group / Trip Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Goa Trip 🏖️, Dinner"
                    value={groupName}
                    onChange={e => setGroupName(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Total Amount ({settings.currency})</label>
                    <input
                      type="number"
                      placeholder="e.g. 2400"
                      value={totalAmount}
                      onChange={e => setTotalAmount(e.target.value)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Paid By</label>
                    <input
                      type="text"
                      placeholder="e.g. Me"
                      value={paidBy}
                      onChange={e => setPaidBy(e.target.value)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Group Members (Comma separated)</label>
                  <input
                    type="text"
                    placeholder="Me, Rahul, Priya, Amit"
                    value={membersInput}
                    onChange={e => setMembersInput(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-extrabold text-xs shadow-lg"
                >
                  Create & Split Expense
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
