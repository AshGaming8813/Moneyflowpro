import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryIcon } from '../common/CategoryIcon';
import { FinancialHealthScore } from '../common/FinancialHealthScore';
import { DailyMood, CategoryName } from '../../types';
import { 
  Wallet, 
  Plus, 
  DollarSign, 
  Receipt, 
  Trash2, 
  Edit2, 
  ChevronRight,
  Flame,
  Users,
  Calendar,
  Smile,
  Meh,
  Frown,
  Star,
  Archive,
  Building2,
  Zap,
  Sparkles
} from 'lucide-react';
import { motion } from 'framer-motion';

export const HomeView: React.FC = () => {
  const { 
    settings, 
    transactions, 
    totalIncome, 
    totalExpense, 
    currentBalance, 
    todayExpense,
    todayIncome,
    remainingDailyBudget,
    daysUntilPayday,
    spendingScore,
    openAddModal, 
    openEditModal, 
    deleteTransaction,
    archiveTransaction,
    quickAddOneTap,
    logMood,
    setActiveTab,
    setIsGamificationModalOpen,
    streakCount,
    t
  } = useApp();

  const [presetTab, setPresetTab] = useState<'quick' | 'starred'>('quick');

  // Time of day greeting
  const hour = new Date().getHours();
  const greetingKey = hour < 12 ? 'goodMorning' : hour < 17 ? 'goodAfternoon' : 'goodEvening';

  const recentTx = transactions.slice(0, 5);

  // One-Tap Quick Presets
  const oneTapPresets = [
    { title: 'Food', amount: 250, category: 'Food' as CategoryName, icon: '🍔' },
    { title: 'Fuel', amount: 500, category: 'Fuel' as CategoryName, icon: '⛽' },
    { title: 'Travel', amount: 120, category: 'Travel' as CategoryName, icon: '🚌' },
    { title: 'Shopping', amount: 800, category: 'Shopping' as CategoryName, icon: '🛒' },
    { title: 'Medicine', amount: 300, category: 'Medicine' as CategoryName, icon: '💊' },
  ];

  // Starred Favorite Presets
  const favoritePresets = [
    { title: 'Tea / Chai', amount: 20, category: 'Food' as CategoryName, icon: '☕' },
    { title: 'Milk Packet', amount: 60, category: 'Food' as CategoryName, icon: '🥛' },
    { title: 'Petrol Fill', amount: 500, category: 'Fuel' as CategoryName, icon: '⛽' },
    { title: 'Coffee', amount: 150, category: 'Food' as CategoryName, icon: '☕' }
  ];

  const activePresets = presetTab === 'quick' ? oneTapPresets : favoritePresets;

  return (
    <div className="space-y-5 pb-24 animate-fadeIn max-w-full">
      {/* 1. Header Greeting & Payday Status */}
      <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-2.5">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white tracking-tight">
            {t(greetingKey)}, {settings.userName} <span className="inline-block animate-bounce">👋</span>
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 font-bold">
            Active Wallet: <span className="font-extrabold text-purple-600 dark:text-purple-400 uppercase">{settings.activeWallet}</span>
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-700 dark:text-purple-300">
            <Calendar className="w-4 h-4 text-purple-500" />
            <div className="text-left">
              <span className="text-[9px] font-bold text-gray-400 uppercase block leading-none">Payday In</span>
              <span className="text-xs font-black">{daysUntilPayday} Days</span>
            </div>
          </div>

          <button
            onClick={() => setIsGamificationModalOpen(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 hover:scale-105 transition-all shadow-xs"
          >
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500 animate-pulse" />
            <span className="text-xs font-bold">{streakCount} Days</span>
          </button>
        </div>
      </div>

      {/* 2. Main Balance Hero Card */}
      <motion.div 
        whileHover={{ scale: 1.01 }}
        className="p-5 sm:p-6 rounded-3xl gradient-purple-blue text-white shadow-xl shadow-purple-500/20 relative overflow-hidden space-y-4"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-purple-100 tracking-wide uppercase flex items-center gap-1.5">
            <Wallet className="w-4 h-4" /> {t('currentBalance')}
          </span>
          <span className="text-xs bg-white/20 px-3 py-1 rounded-full font-bold uppercase tracking-wider backdrop-blur-md">
            {settings.activeWallet.toUpperCase()}
          </span>
        </div>

        <div>
          <span className="text-3xl sm:text-4xl font-black tracking-tight block">
            {settings.isPrivacyMode ? '₹ • • • • •' : `${settings.currency}${currentBalance.toLocaleString()}`}
          </span>
        </div>

        {/* Dynamic Today Spend Bar */}
        <div className="pt-3 border-t border-white/20 grid grid-cols-3 gap-2 text-xs">
          <div>
            <span className="text-[10px] uppercase text-purple-200 block font-bold">Today Spent</span>
            <span className="font-extrabold text-rose-200">
              {settings.isPrivacyMode ? '₹ • • •' : `${settings.currency}${todayExpense.toLocaleString()}`}
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase text-purple-200 block font-bold">Today Income</span>
            <span className="font-extrabold text-emerald-200">
              {settings.isPrivacyMode ? '₹ • • •' : `${settings.currency}${todayIncome.toLocaleString()}`}
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase text-purple-200 block font-bold">Net Surplus</span>
            <span className="font-extrabold text-white">
              {settings.isPrivacyMode ? '₹ • • •' : `+${settings.currency}${(totalIncome - totalExpense).toLocaleString()}`}
            </span>
          </div>
        </div>
      </motion.div>

      {/* 3. Quick Financial Action Chips */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 px-0.5">
          Quick Financial Actions
        </h3>
        
        <div className="flex flex-wrap gap-2 w-full">
          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => openAddModal('expense')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-950 dark:text-rose-100 border border-rose-300 dark:border-rose-800 text-xs font-extrabold hover:bg-rose-100 transition-all shadow-xs"
          >
            <div className="w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center font-black">
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </div>
            <span>{t('addExpense')}</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => openAddModal('income')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-950 dark:text-emerald-100 border border-emerald-300 dark:border-emerald-800 text-xs font-extrabold hover:bg-emerald-100 transition-all shadow-xs"
          >
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center font-black">
              <DollarSign className="w-3.5 h-3.5 stroke-[3]" />
            </div>
            <span>{t('addIncome')}</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => setActiveTab('loans')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-purple-50 dark:bg-purple-950/60 text-purple-950 dark:text-purple-100 border border-purple-300 dark:border-purple-800 text-xs font-extrabold hover:bg-purple-100 transition-all shadow-xs"
          >
            <div className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center">
              <Building2 className="w-3.5 h-3.5" />
            </div>
            <span>Loans & Udhar</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => setActiveTab('splitwise')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-950 dark:text-indigo-100 border border-indigo-300 dark:border-indigo-800 text-xs font-extrabold hover:bg-indigo-100 transition-all shadow-xs"
          >
            <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center">
              <Users className="w-3.5 h-3.5" />
            </div>
            <span>Split Udhar</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => setActiveTab('bills')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-950 dark:text-amber-100 border border-amber-300 dark:border-amber-800 text-xs font-extrabold hover:bg-amber-100 transition-all shadow-xs"
          >
            <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center">
              <Receipt className="w-3.5 h-3.5" />
            </div>
            <span>{t('payBill')}</span>
          </motion.button>
        </div>
      </div>

      {/* 4. Unified Presets Section */}
      <div className="p-4 rounded-3xl glass-card border border-white/20 space-y-3">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setPresetTab('quick')}
            className={`px-3 py-1 rounded-xl text-xs font-extrabold transition-all flex items-center gap-1 ${
              presetTab === 'quick'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" /> One-Tap Presets
          </button>
          <button
            onClick={() => setPresetTab('starred')}
            className={`px-3 py-1 rounded-xl text-xs font-extrabold transition-all flex items-center gap-1 ${
              presetTab === 'starred'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
            }`}
          >
            <Star className="w-3.5 h-3.5" /> Starred Expenses
          </button>
        </div>

        {/* Clean Pill Chips Bar */}
        <div className="flex flex-wrap gap-2">
          {activePresets.map(preset => (
            <motion.button
              key={preset.title}
              whileTap={{ scale: 0.92 }}
              onClick={() => quickAddOneTap(preset.amount, preset.category, preset.title)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-full text-xs font-extrabold border shadow-xs transition-all ${
                presetTab === 'quick'
                  ? 'bg-purple-50 dark:bg-purple-950/60 text-purple-950 dark:text-purple-100 border-purple-300 dark:border-purple-800 hover:bg-purple-100'
                  : 'bg-amber-50 dark:bg-amber-950/60 text-amber-950 dark:text-amber-100 border-amber-300 dark:border-amber-800 hover:bg-amber-100'
              }`}
            >
              <span className="text-base">{preset.icon}</span>
              <span>{preset.title}</span>
              <span className={`px-2 py-0.5 rounded-md text-xs font-black ${
                presetTab === 'quick'
                  ? 'bg-purple-200 dark:bg-purple-800 text-purple-900 dark:text-purple-100'
                  : 'bg-amber-200 dark:bg-amber-800 text-amber-900 dark:text-amber-100'
              }`}>
                {settings.currency}{preset.amount}
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* 5. 😊 Daily Mood Tracker Widget */}
      <div className="p-3.5 rounded-3xl glass-card border border-white/20 flex flex-col xs:flex-row xs:items-center justify-between gap-2">
        <h4 className="font-extrabold text-xs text-gray-900 dark:text-white flex items-center gap-1.5">
          <Smile className="w-4 h-4 text-purple-500" /> {t('dailyMood')}
        </h4>

        <div className="flex items-center gap-2">
          <button
            onClick={() => logMood('happy')}
            className="flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 text-xs font-extrabold hover:scale-105 transition-all"
          >
            <Smile className="w-4 h-4 text-emerald-500" /> Happy
          </button>
          <button
            onClick={() => logMood('normal')}
            className="flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-200 text-xs font-extrabold hover:scale-105 transition-all"
          >
            <Meh className="w-4 h-4 text-blue-500" /> Normal
          </button>
          <button
            onClick={() => logMood('stressed')}
            className="flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 text-xs font-extrabold hover:scale-105 transition-all"
          >
            <Frown className="w-4 h-4 text-rose-500" /> Stressed
          </button>
        </div>
      </div>

      {/* 6. Financial Health Score Gauge */}
      <FinancialHealthScore />

      {/* 7. Recent Transactions List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-0.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">
            {t('recentTransactions')}
          </h3>
          <button
            onClick={() => setActiveTab('transactions')}
            className="text-xs font-extrabold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-0.5"
          >
            View All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentTx.length === 0 ? (
          <div className="p-6 text-center glass-card rounded-3xl space-y-1">
            <Wallet className="w-8 h-8 text-gray-300 mx-auto" />
            <h4 className="font-bold text-xs text-gray-700 dark:text-gray-300">No Transactions In This Wallet</h4>
            <p className="text-xs text-gray-400">Tap + to add your first expense or income entry!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {recentTx.map(tx => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3.5 rounded-3xl glass-card flex items-center justify-between hover:shadow-xs transition-all group border border-white/20"
              >
                <div className="flex items-center gap-3">
                  <CategoryIcon category={tx.category} size={22} />
                  <div>
                    <h4 className="font-bold text-xs text-gray-900 dark:text-gray-100">
                      {tx.description || tx.category}
                    </h4>
                    <div className="flex items-center gap-1.5 text-xs text-gray-400 font-medium">
                      <span>{tx.date}</span>
                      <span>•</span>
                      <span className="bg-gray-100 dark:bg-white/10 px-1.5 py-0.2 rounded-md font-bold text-gray-700 dark:text-gray-300">
                        {tx.paymentMethod}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-sm font-black ${
                    tx.type === 'income' ? 'text-emerald-500' : 'text-rose-500'
                  }`}>
                    {settings.isPrivacyMode ? '₹ • • •' : `${tx.type === 'income' ? '+' : '-'}${settings.currency}${tx.amount.toLocaleString()}`}
                  </span>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEditModal(tx)}
                      className="p-1 rounded-lg hover:bg-gray-200 dark:hover:bg-white/10 text-gray-500"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => archiveTransaction(tx.id)}
                      className="p-1 rounded-lg hover:bg-purple-100 text-purple-600"
                    >
                      <Archive className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteTransaction(tx.id)}
                      className="p-1 rounded-lg hover:bg-rose-100 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
