import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Building2, 
  Plus, 
  CheckCircle2, 
  Clock, 
  Trash2, 
  Calculator, 
  X,
  CreditCard,
  UserCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const LoansView: React.FC = () => {
  const { loans, settings, addLoan, payLoanKist, deleteLoan, showToast, t } = useApp();

  const [isAddLoanOpen, setIsAddLoanOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'borrowed' | 'given'>('borrowed');
  const [totalAmount, setTotalAmount] = useState('');
  const [kistAmount, setKistAmount] = useState('');
  const [frequency, setFrequency] = useState<'Monthly' | 'Weekly' | 'Yearly'>('Monthly');
  const [nextDueDate, setNextDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [interestRate, setInterestRate] = useState('8.5');
  const [totalInstallments, setTotalInstallments] = useState('24');
  const [notes, setNotes] = useState('');

  // Calculations
  const totalBorrowedPrincipal = loans
    .filter(l => l.type === 'borrowed')
    .reduce((sum, l) => sum + l.remainingAmount, 0);

  const totalBorrowedMonthlyKist = loans
    .filter(l => l.type === 'borrowed' && !l.isFullyPaid)
    .reduce((sum, l) => sum + l.kistAmount, 0);

  const totalGivenPrincipal = loans
    .filter(l => l.type === 'given')
    .reduce((sum, l) => sum + l.remainingAmount, 0);

  // Auto calculate EMI helper
  const calculateEMI = () => {
    const P = parseFloat(totalAmount);
    const r = (parseFloat(interestRate) || 0) / 12 / 100;
    const n = parseFloat(totalInstallments) || 12;

    if (P > 0 && n > 0) {
      if (r > 0) {
        const emi = Math.round((P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1));
        setKistAmount(emi.toString());
      } else {
        setKistAmount(Math.round(P / n).toString());
      }
      showToast('EMI Kist amount calculated automatically!', 'info');
    }
  };

  const handleCreateLoan = (e: React.FormEvent) => {
    e.preventDefault();
    const principal = parseFloat(totalAmount);
    const kist = parseFloat(kistAmount);
    const totalInst = parseInt(totalInstallments) || 12;

    if (!title || !principal || principal <= 0 || !kist || kist <= 0) {
      showToast('Please enter valid loan details and Kist amount', 'error');
      return;
    }

    addLoan({
      title,
      type,
      totalAmount: principal,
      remainingAmount: principal,
      kistAmount: kist,
      frequency,
      nextDueDate,
      interestRate: parseFloat(interestRate) || 0,
      totalInstallments: totalInst,
      notes
    });

    setIsAddLoanOpen(false);
    setTitle('');
    setTotalAmount('');
    setKistAmount('');
  };

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
            {t('loansTitle')}
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
            Track borrowed loans, given loans (Udhar), and regular Kist reminders
          </p>
        </div>

        <button
          onClick={() => setIsAddLoanOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-extrabold shadow-lg shadow-purple-500/30 hover:opacity-90 transition-all"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Loan</span>
        </button>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* Borrowed Loans Card */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-rose-500 to-pink-600 text-white shadow-xl shadow-rose-500/20 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-100 flex items-center gap-1.5">
              <CreditCard className="w-4 h-4" /> Total Borrowed Loans
            </span>
            <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold uppercase">
              Owed by You
            </span>
          </div>

          <div>
            <p className="text-3xl font-black tracking-tight">
              {settings.currency}{totalBorrowedPrincipal.toLocaleString()}
            </p>
            <p className="text-xs text-rose-100 mt-1 font-semibold">
              Monthly Kist Outflow: <span className="font-extrabold text-white">{settings.currency}{totalBorrowedMonthlyKist.toLocaleString()}</span>
            </p>
          </div>
        </div>

        {/* Given Loans Card */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-xl shadow-emerald-500/20 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-100 flex items-center gap-1.5">
              <UserCheck className="w-4 h-4" /> Total Money Given / Lent (Udhar)
            </span>
            <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold uppercase">
              To Receive
            </span>
          </div>

          <div>
            <p className="text-3xl font-black tracking-tight">
              {settings.currency}{totalGivenPrincipal.toLocaleString()}
            </p>
            <p className="text-xs text-emerald-100 mt-1 font-semibold">
              Expected Recovery Balance
            </p>
          </div>
        </div>
      </div>

      {/* Active Loans List */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500 px-1">
          Active Loans & Kist Installments
        </h3>

        {loans.length === 0 ? (
          <div className="p-10 text-center glass-card rounded-3xl space-y-2">
            <Building2 className="w-12 h-12 text-purple-400 mx-auto" />
            <h4 className="font-bold text-gray-800 dark:text-white">No Loans Being Tracked</h4>
            <p className="text-xs text-gray-400">Add home loans, car loans, or personal money lent to friends (Udhar).</p>
          </div>
        ) : (
          loans.map(loan => {
            const percentPaid = Math.min(100, Math.round(((loan.totalAmount - loan.remainingAmount) / loan.totalAmount) * 100));

            return (
              <motion.div
                key={loan.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 rounded-3xl glass-card space-y-4 relative overflow-hidden group border border-white/30 dark:border-white/10"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-md ${
                      loan.type === 'borrowed' ? 'bg-rose-500' : 'bg-emerald-500'
                    }`}>
                      <Building2 className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                          {loan.title}
                        </h3>
                        <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase ${
                          loan.type === 'borrowed'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                        }`}>
                          {loan.type === 'borrowed' ? 'Loan Taken' : 'Money Lent (Udhar)'}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 font-medium mt-0.5">
                        Total Principal: {settings.currency}{loan.totalAmount.toLocaleString()} ({loan.interestRate}% Interest)
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => deleteLoan(loan.id)}
                    className="p-2 rounded-xl text-gray-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-gray-600 dark:text-gray-300">
                      Remaining Balance: <span className="font-black text-rose-500">{settings.currency}{loan.remainingAmount.toLocaleString()}</span>
                    </span>
                    <span className="text-purple-600 dark:text-purple-400">
                      {loan.installmentsPaid} / {loan.totalInstallments} Kists Paid ({percentPaid}%)
                    </span>
                  </div>
                  <div className="w-full h-3 bg-gray-200 dark:bg-white/10 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        loan.type === 'borrowed'
                          ? 'bg-gradient-to-r from-rose-500 to-purple-600'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-600'
                      }`}
                      style={{ width: `${percentPaid}%` }}
                    />
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-white/5 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase block">
                      {loan.frequency} Kist Installment
                    </span>
                    <span className="text-base font-black text-gray-900 dark:text-white">
                      {settings.currency}{loan.kistAmount.toLocaleString()}
                    </span>
                    <span className="text-[10px] text-amber-500 font-semibold block flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" /> Due {loan.nextDueDate}
                    </span>
                  </div>

                  {!loan.isFullyPaid ? (
                    <button
                      onClick={() => payLoanKist(loan.id)}
                      className={`px-4 py-2.5 rounded-2xl text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 ${
                        loan.type === 'borrowed'
                          ? 'bg-rose-500 hover:bg-rose-600 shadow-rose-500/30'
                          : 'bg-emerald-500 hover:bg-emerald-600 shadow-emerald-500/30'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{loan.type === 'borrowed' ? 'Pay Kist' : 'Receive Kist'}</span>
                    </button>
                  ) : (
                    <span className="text-xs font-extrabold text-emerald-500 bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/30">
                      Fully Settled 🎉
                    </span>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Add Loan Modal */}
      <AnimatePresence>
        {isAddLoanOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                  Add New Loan / Udhar Tracker 🏦
                </h3>
                <button onClick={() => setIsAddLoanOpen(false)}>
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <form onSubmit={handleCreateLoan} className="space-y-3">
                <div className="flex p-1 bg-gray-100 dark:bg-black/40 rounded-2xl">
                  <button
                    type="button"
                    onClick={() => setType('borrowed')}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                      type === 'borrowed' ? 'bg-rose-500 text-white shadow-md' : 'text-gray-500'
                    }`}
                  >
                    Borrowed Loan (EMI I Pay) 🔴
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('given')}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                      type === 'given' ? 'bg-emerald-500 text-white shadow-md' : 'text-gray-500'
                    }`}
                  >
                    Money Lent / Udhar Given 🟢
                  </button>
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase">Loan Title / Person</label>
                  <input
                    type="text"
                    placeholder="e.g. HDFC Home Loan, Friend Amit"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Total Amount ({settings.currency})</label>
                    <input
                      type="number"
                      placeholder="e.g. 450000"
                      value={totalAmount}
                      onChange={e => setTotalAmount(e.target.value)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Interest Rate (% p.a.)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="e.g. 8.5"
                      value={interestRate}
                      onChange={e => setInterestRate(e.target.value)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Total Kists (Installments)</label>
                    <input
                      type="number"
                      placeholder="e.g. 36"
                      value={totalInstallments}
                      onChange={e => setTotalInstallments(e.target.value)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Kist Installment ({settings.currency})</label>
                    <div className="flex gap-1">
                      <input
                        type="number"
                        placeholder="e.g. 12500"
                        value={kistAmount}
                        onChange={e => setKistAmount(e.target.value)}
                        className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={calculateEMI}
                        className="p-3 rounded-2xl bg-purple-600 text-white font-bold text-xs shrink-0"
                        title="Auto-calculate EMI"
                      >
                        <Calculator className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Due Frequency</label>
                    <select
                      value={frequency}
                      onChange={e => setFrequency(e.target.value as any)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                    >
                      <option value="Monthly">Monthly Kist</option>
                      <option value="Weekly">Weekly Kist</option>
                      <option value="Yearly">Yearly Kist</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase">Next Kist Due Date</label>
                    <input
                      type="date"
                      value={nextDueDate}
                      onChange={e => setNextDueDate(e.target.value)}
                      className="w-full p-3 rounded-2xl bg-gray-100 dark:bg-white/5 border text-xs font-medium text-gray-900 dark:text-white focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 text-white font-extrabold text-xs shadow-lg"
                >
                  Save Loan & Start Tracking Kists
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
