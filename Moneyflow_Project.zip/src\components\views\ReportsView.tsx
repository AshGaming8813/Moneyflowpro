import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  PieChart as PieChartIcon, 
  TrendingUp, 
  BarChart2, 
  Sparkles
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  BarChart, 
  Bar, 
  Legend 
} from 'recharts';

const COLORS = ['#7C4DFF', '#4FC3F7', '#4CAF50', '#FF9800', '#EC407A', '#9C27B0', '#3F51B5', '#00BCD4'];

export const ReportsView: React.FC = () => {
  const { transactions, settings, t } = useApp();
  const [timeframe, setTimeframe] = useState<'Daily' | 'Weekly' | 'Monthly' | 'Yearly'>('Monthly');

  // 1. Category Pie Chart Data (Dynamic)
  const categoryMap: Record<string, number> = {};
  transactions
    .filter(t => t.type === 'expense')
    .forEach(t => {
      categoryMap[t.category] = (categoryMap[t.category] || 0) + t.amount;
    });

  const pieData = Object.keys(categoryMap).map(category => ({
    name: category,
    value: categoryMap[category]
  }));

  // 2. Dynamic Daily Spending Line Chart Data (Computed from last 7 days of real transactions)
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dailyMap: Record<string, { expense: number; income: number }> = {};
  
  const today = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateKey = d.toISOString().split('T')[0];
    dailyMap[dateKey] = { expense: 0, income: 0 };
  }

  transactions.forEach(t => {
    if (dailyMap[t.date]) {
      if (t.type === 'expense') dailyMap[t.date].expense += t.amount;
      if (t.type === 'income') dailyMap[t.date].income += t.amount;
    }
  });

  const lineData = Object.keys(dailyMap).map(dateKey => {
    const d = new Date(dateKey);
    const dayLabel = `${daysOfWeek[d.getDay()]} (${d.getDate()})`;
    return {
      day: dayLabel,
      expense: dailyMap[dateKey].expense,
      income: dailyMap[dateKey].income
    };
  });

  // 3. Dynamic Monthly Income vs Expense Comparison Bar Chart Data
  const monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyMap: Record<string, { Income: number; Expense: number }> = {};

  transactions.forEach(t => {
    const d = new Date(t.date);
    const monthLabel = `${monthNamesShort[d.getMonth()]} ${d.getFullYear()}`;
    if (!monthlyMap[monthLabel]) {
      monthlyMap[monthLabel] = { Income: 0, Expense: 0 };
    }
    if (t.type === 'income') monthlyMap[monthLabel].Income += t.amount;
    if (t.type === 'expense') monthlyMap[monthLabel].Expense += t.amount;
  });

  const barData = Object.keys(monthlyMap).map(mLabel => ({
    period: mLabel,
    Income: monthlyMap[mLabel].Income,
    Expense: monthlyMap[mLabel].Expense
  }));

  const sortedCategories = [...pieData].sort((a, b) => b.value - a.value);
  const highestCategory = sortedCategories[0]?.name || 'N/A';
  const highestCategoryAmount = sortedCategories[0]?.value || 0;

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Title & Timeframe Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
            {t('reportsTitle')}
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
            Visual breakdown of your financial flows
          </p>
        </div>

        <div className="flex p-1 bg-gray-200/60 dark:bg-white/5 rounded-2xl self-start sm:self-auto">
          {(['Daily', 'Weekly', 'Monthly', 'Yearly'] as const).map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                timeframe === tf
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* AI Smart Monthly Insight Box */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-slate-900 text-white shadow-xl border border-purple-500/30 relative overflow-hidden">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-2xl bg-purple-500/20 border border-purple-400/30 text-purple-300 shrink-0">
            <Sparkles className="w-6 h-6 text-purple-300" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm text-purple-200 uppercase tracking-wider">
              Smart AI Monthly Insights
            </h3>
            <p className="text-xs text-gray-200 mt-1 leading-relaxed">
              {pieData.length > 0 ? (
                <>
                  Your highest expenditure is on <span className="font-bold text-amber-300">{highestCategory}</span> ({settings.currency}{highestCategoryAmount.toLocaleString()}). Keep tracking daily entries for accurate analytics!
                </>
              ) : (
                'Add your first income and expense entries to view AI insights and pie chart distribution!'
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Pie Chart: Expense Distribution */}
      <div className="p-5 rounded-3xl glass-card space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-base text-gray-800 dark:text-white flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-purple-600" /> Expense Distribution
            </h3>
            <p className="text-[11px] text-gray-400">Breakdown of spending by category</p>
          </div>
        </div>

        {pieData.length === 0 ? (
          <div className="text-center py-10 space-y-2">
            <PieChartIcon className="w-10 h-10 text-gray-300 mx-auto" />
            <p className="text-xs font-bold text-gray-400">No Expense Data Recorded Yet</p>
            <p className="text-[11px] text-gray-400">Log an expense to see your category pie chart update dynamically.</p>
          </div>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${settings.currency}${val}`, 'Amount']}
                  contentStyle={{
                    backgroundColor: 'rgba(20, 20, 20, 0.9)',
                    borderRadius: '16px',
                    borderColor: 'rgba(255,255,255,0.1)',
                    color: '#fff',
                    fontSize: '12px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Line Chart: Daily Spending Trend */}
      <div className="p-5 rounded-3xl glass-card space-y-4">
        <div>
          <h3 className="font-extrabold text-base text-gray-800 dark:text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-500" /> Daily Spending Trend (Last 7 Days)
          </h3>
          <p className="text-[11px] text-gray-400">Real-time daily outflow updates</p>
        </div>

        <div className="h-60 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={lineData}>
              <XAxis dataKey="day" stroke="#888888" fontSize={11} />
              <YAxis stroke="#888888" fontSize={11} />
              <Tooltip
                formatter={(val: any) => [`${settings.currency}${val}`, 'Amount']}
                contentStyle={{
                  backgroundColor: 'rgba(20, 20, 20, 0.9)',
                  borderRadius: '16px',
                  color: '#fff',
                  fontSize: '12px'
                }}
              />
              <Line type="monotone" dataKey="expense" stroke="#EC407A" strokeWidth={3} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bar Chart: Income vs Expense Comparison */}
      <div className="p-5 rounded-3xl glass-card space-y-4">
        <div>
          <h3 className="font-extrabold text-base text-gray-800 dark:text-white flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-blue-500" /> Monthly Income vs Expense Comparison
          </h3>
          <p className="text-[11px] text-gray-400">Monthly totals computed straight from your logs</p>
        </div>

        {barData.length === 0 ? (
          <div className="text-center py-8 text-xs text-gray-400">
            No monthly data recorded yet. Add transactions to generate monthly comparison bars.
          </div>
        ) : (
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <XAxis dataKey="period" stroke="#888888" fontSize={11} />
                <YAxis stroke="#888888" fontSize={11} />
                <Tooltip
                  formatter={(val: any) => [`${settings.currency}${val}`, 'Total']}
                  contentStyle={{
                    backgroundColor: 'rgba(20, 20, 20, 0.9)',
                    borderRadius: '16px',
                    color: '#fff',
                    fontSize: '12px'
                  }}
                />
                <Legend />
                <Bar dataKey="Income" fill="#4CAF50" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Expense" fill="#EC407A" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};
