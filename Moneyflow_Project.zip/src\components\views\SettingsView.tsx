import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { AppLanguage } from '../../types';
import { 
  Sun, 
  Moon, 
  DollarSign, 
  Download, 
  Upload, 
  FileText, 
  Lock, 
  Fingerprint, 
  Globe,
  Palette,
  Archive,
  Trophy,
  Calendar
} from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export const SettingsView: React.FC = () => {
  const { 
    settings, 
    updateSettings, 
    toggleTheme, 
    exportBackupData, 
    importBackupData,
    transactions,
    totalIncome,
    totalExpense,
    currentBalance,
    setActiveTab,
    showToast,
    t
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportPDF = () => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.setTextColor(124, 77, 255);
      doc.text('MoneyFlow Financial Statement', 14, 22);

      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Generated for ${settings.userName} on ${new Date().toLocaleDateString()}`, 14, 28);

      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text(`Current Balance: ${settings.currency}${currentBalance.toLocaleString()}`, 14, 38);
      doc.text(`Total Income: ${settings.currency}${totalIncome.toLocaleString()}`, 14, 44);
      doc.text(`Total Expense: ${settings.currency}${totalExpense.toLocaleString()}`, 14, 50);

      const tableRows = transactions.map(t => [
        t.date,
        t.description,
        t.category,
        t.paymentMethod,
        t.type.toUpperCase(),
        `${settings.currency}${t.amount.toLocaleString()}`
      ]);

      autoTable(doc, {
        startY: 56,
        head: [['Date', 'Description', 'Category', 'Method', 'Type', 'Amount']],
        body: tableRows,
        headStyles: { fillColor: [124, 77, 255] },
        styles: { fontSize: 9 }
      });

      doc.save(`MoneyFlow_Report_${settings.userName}_${new Date().toISOString().split('T')[0]}.pdf`);
      showToast('PDF Financial Report downloaded!', 'success');
    } catch {
      showToast('Failed to generate PDF report', 'error');
    }
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Date', 'Type', 'Category', 'Description', 'Amount', 'Payment Method', 'Notes'];
    const rows = transactions.map(t => [
      t.id,
      t.date,
      t.type,
      t.category,
      `"${t.description.replace(/"/g, '""')}"`,
      t.amount,
      t.paymentMethod,
      `"${(t.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `MoneyFlow_Transactions_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('CSV export downloaded!', 'success');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          importBackupData(content);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Title */}
      <div>
        <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
          Settings & Personalization ⚙️
        </h2>
        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
          Personalize themes, language, budget limits & security
        </p>
      </div>

      {/* User Profile Summary */}
      <div className="p-5 rounded-3xl glass-card flex items-center justify-between">
        <div className="flex items-center gap-3.5">
          <img
            src={settings.userAvatar}
            alt={settings.userName}
            className="w-14 h-14 rounded-2xl object-cover ring-4 ring-purple-500/30"
          />
          <div>
            <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
              {settings.userName}
            </h3>
            <p className="text-xs text-gray-400">MoneyFlow PRO Member</p>
          </div>
        </div>

        <button
          onClick={() => {
            const newName = prompt('Enter your name:', settings.userName);
            if (newName) updateSettings({ userName: newName });
          }}
          className="px-3.5 py-1.5 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-300 font-bold text-xs"
        >
          Edit Profile
        </button>
      </div>

      {/* Quick Navigation Links */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => setActiveTab('challenges')}
          className="p-4 rounded-3xl glass-card border border-white/20 flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-white/5 transition-all text-left"
        >
          <div className="p-2.5 rounded-2xl bg-amber-500 text-white shadow-md">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-gray-900 dark:text-white">Weekly Challenges</h4>
            <p className="text-[10px] text-gray-400">Rewards & Referral points</p>
          </div>
        </button>

        <button
          onClick={() => setActiveTab('archive')}
          className="p-4 rounded-3xl glass-card border border-white/20 flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-white/5 transition-all text-left"
        >
          <div className="p-2.5 rounded-2xl bg-indigo-500 text-white shadow-md">
            <Archive className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-gray-900 dark:text-white">Archive Vault</h4>
            <p className="text-[10px] text-gray-400">Archived logs history</p>
          </div>
        </button>
      </div>

      {/* Language & Theme Personalization */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1">
          App Language & Personalization
        </h4>

        <div className="p-4 rounded-3xl glass-card space-y-4">
          {/* Language Picker */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-blue-500/10 text-blue-500">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">App Language</h4>
                <p className="text-[11px] text-gray-400">Select preferred language</p>
              </div>
            </div>

            <select
              value={settings.language}
              onChange={e => updateSettings({ language: e.target.value as AppLanguage })}
              className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-white/10 text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
            >
              <option value="en">English 🇬🇧</option>
              <option value="hi">हिंदी (Hindi) 🇮🇳</option>
              <option value="mr">मराठी (Marathi) 🇮🇳</option>
              <option value="pa">ਪੰਜਾਬੀ (Punjabi) 🇮🇳</option>
              <option value="gu">ગુજરાતી (Gujarati) 🇮🇳</option>
              <option value="ta">தமிழ் (Tamil) 🇮🇳</option>
              <option value="bn">বাংলা (Bengali) 🇮🇳</option>
            </select>
          </div>

          {/* Dark / Light Mode Switcher */}
          <div className="border-t border-gray-100 dark:border-white/5 pt-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                {settings.theme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">Dark Theme Mode</h4>
                <p className="text-[11px] text-gray-400">Deep dark UI with glowing accents</p>
              </div>
            </div>

            <button
              onClick={toggleTheme}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center ${
                settings.theme === 'dark' ? 'bg-purple-600 justify-end' : 'bg-gray-300 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md" />
            </button>
          </div>

          {/* Currency */}
          <div className="border-t border-gray-100 dark:border-white/5 pt-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">App Currency</h4>
                <p className="text-[11px] text-gray-400">Select active currency symbol</p>
              </div>
            </div>

            <select
              value={settings.currency}
              onChange={e => updateSettings({ currency: e.target.value })}
              className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-white/10 text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
            >
              <option value="₹">₹ (INR)</option>
              <option value="$">$ (USD)</option>
              <option value="€">€ (EUR)</option>
              <option value="£">£ (GBP)</option>
              <option value="¥">¥ (JPY)</option>
            </select>
          </div>

          {/* Payday Date */}
          <div className="border-t border-gray-100 dark:border-white/5 pt-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-purple-500/10 text-purple-500">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">Monthly Payday Date</h4>
                <p className="text-[11px] text-gray-400">Day of month salary is credited</p>
              </div>
            </div>

            <select
              value={settings.paydayDate}
              onChange={e => updateSettings({ paydayDate: parseInt(e.target.value) || 1 })}
              className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-white/10 text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
            >
              {[1, 5, 10, 15, 25, 30].map(day => (
                <option key={day} value={day}>{day}th of month</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1">
          Security & Biometrics
        </h4>

        <div className="p-4 rounded-3xl glass-card space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-rose-500/10 text-rose-500">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">Security PIN Lock</h4>
                <p className="text-[11px] text-gray-400">Require PIN passcode on startup</p>
              </div>
            </div>

            <button
              onClick={() => updateSettings({ securityLockEnabled: !settings.securityLockEnabled })}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center ${
                settings.securityLockEnabled ? 'bg-rose-500 justify-end' : 'bg-gray-300 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md" />
            </button>
          </div>

          <div className="border-t border-gray-100 dark:border-white/5 pt-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-purple-500/10 text-purple-500">
                <Fingerprint className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">Fingerprint & Face Unlock</h4>
                <p className="text-[11px] text-gray-400">Use device biometrics</p>
              </div>
            </div>

            <button
              onClick={() => updateSettings({ biometricEnabled: !settings.biometricEnabled })}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center ${
                settings.biometricEnabled ? 'bg-purple-600 justify-end' : 'bg-gray-300 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md" />
            </button>
          </div>
        </div>
      </div>

      {/* Backup & Export */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1">
          Export & Data Management
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={handleExportPDF}
            className="p-4 rounded-3xl glass-card flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-white/5 transition-all text-left"
          >
            <div className="p-3 rounded-2xl bg-rose-500 text-white shadow-md">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-gray-900 dark:text-white">Export PDF Statement</h4>
              <p className="text-[10px] text-gray-400">Printable monthly report</p>
            </div>
          </button>

          <button
            onClick={handleExportCSV}
            className="p-4 rounded-3xl glass-card flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-white/5 transition-all text-left"
          >
            <div className="p-3 rounded-2xl bg-emerald-500 text-white shadow-md">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-gray-900 dark:text-white">Export CSV File</h4>
              <p className="text-[10px] text-gray-400">Spreadsheet compatible format</p>
            </div>
          </button>

          <button
            onClick={exportBackupData}
            className="p-4 rounded-3xl glass-card flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-white/5 transition-all text-left"
          >
            <div className="p-3 rounded-2xl bg-purple-600 text-white shadow-md">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-gray-900 dark:text-white">Backup JSON Data</h4>
              <p className="text-[10px] text-gray-400">Full data backup file</p>
            </div>
          </button>

          <label className="p-4 rounded-3xl glass-card flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-white/5 transition-all text-left cursor-pointer">
            <div className="p-3 rounded-2xl bg-blue-500 text-white shadow-md">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-gray-900 dark:text-white">Restore JSON Backup</h4>
              <p className="text-[10px] text-gray-400">Import backup file</p>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
