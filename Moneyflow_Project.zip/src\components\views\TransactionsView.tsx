import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryIcon } from '../common/CategoryIcon';
import { Transaction } from '../../types';
import { 
  Search, 
  Filter, 
  Trash2, 
  Edit2, 
  Archive, 
  ArrowUpRight, 
  ArrowDownRight,
  SlidersHorizontal,
  Calendar,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const TransactionsView: React.FC = () => {
  const { 
    transactions, 
    settings, 
    deleteTransaction, 
    archiveTransaction, 
    openEditModal,
    t
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'income' | 'expense'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMethod, setSelectedMethod] = useState<string>('all');

  // Filter logic
  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      // Type Filter
      if (selectedType !== 'all' && tx.type !== selectedType) return false;
      
      // Category Filter
      if (selectedCategory !== 'all' && tx.category !== selectedCategory) return false;

      // Method Filter
      if (selectedMethod !== 'all' && tx.paymentMethod !== selectedMethod) return false;

      // Search Query
      if (searchTerm.trim() !== '') {
        const query = searchTerm.toLowerCase();
        const matchesDesc = tx.description.toLowerCase().includes(query);
        const matchesCategory = tx.category.toLowerCase().includes(query);
        const matchesMethod = tx.paymentMethod.toLowerCase().includes(query);
        const matchesAmount = tx.amount.toString().includes(query);
        return matchesDesc || matchesCategory || matchesMethod || matchesAmount;
      }

      return true;
    });
  }, [transactions, selectedType, selectedCategory, selectedMethod, searchTerm]);

  // Categories list for dropdown
  const categoriesList = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach(t => set.add(t.category));
    return Array.from(set);
  }, [transactions]);

  return (
    <div className="space-y-5 pb-24 animate-fadeIn">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-black text-gray-800 dark:text-white tracking-tight">
            {t('allTransactionsTitle')}
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
            Search, filter & manage all income and expense logs
          </p>
        </div>

        {/* Type Switcher Pills */}
        <div className="flex p-1 bg-gray-200/70 dark:bg-white/10 rounded-2xl self-start sm:self-auto">
          {(['all', 'income', 'expense'] as const).map(type => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all capitalize ${
                selectedType === type
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-800 dark:hover:text-white'
              }`}
            >
              {type === 'all' ? 'All Logs' : type}
            </button>
          ))}
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-gray-400 absolute left-4 top-3.5" />
        <input
          type="text"
          placeholder={t('searchPlaceholder')}
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full pl-11 pr-10 py-3 rounded-2xl bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-xs font-semibold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 shadow-sm"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category & Payment Method Filters */}
      <div className="flex flex-wrap gap-2">
        <select
          value={selectedCategory}
          onChange={e => setSelectedCategory(e.target.value)}
          className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-white/10 text-xs font-bold text-gray-800 dark:text-white focus:outline-none cursor-pointer"
        >
          <option value="all">All Categories 📂</option>
          {categoriesList.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>

        <select
          value={selectedMethod}
          onChange={e => setSelectedMethod(e.target.value)}
          className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-white/10 text-xs font-bold text-gray-800 dark:text-white focus:outline-none cursor-pointer"
        >
          <option value="all">All Payment Methods 💳</option>
          <option value="UPI">UPI</option>
          <option value="Cash">Cash</option>
          <option value="Card">Card</option>
          <option value="NetBanking">NetBanking</option>
        </select>

        {(selectedCategory !== 'all' || selectedMethod !== 'all' || selectedType !== 'all' || searchTerm) && (
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSelectedMethod('all');
              setSelectedType('all');
              setSearchTerm('');
            }}
            className="px-3 py-2 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 text-xs font-bold"
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Transactions List */}
      <div className="space-y-3">
        {filteredTransactions.length === 0 ? (
          <div className="p-10 text-center glass-card rounded-3xl space-y-2">
            <Filter className="w-10 h-10 text-gray-400 mx-auto" />
            <h4 className="font-bold text-gray-800 dark:text-white">No Matching Transactions Found</h4>
            <p className="text-xs text-gray-400">Try adjusting your search terms or filter selections.</p>
          </div>
        ) : (
          filteredTransactions.map(tx => (
            <motion.div
              key={tx.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-3xl glass-card flex items-center justify-between hover:shadow-md transition-all group"
            >
              <div className="flex items-center gap-3">
                <CategoryIcon category={tx.category} size={22} />
                <div>
                  <h4 className="font-bold text-sm text-gray-800 dark:text-gray-100">
                    {tx.description || tx.category}
                  </h4>
                  <div className="flex items-center gap-2 text-[11px] text-gray-400">
                    <span>{tx.date}</span>
                    <span>•</span>
                    <span className="bg-gray-100 dark:bg-white/10 px-2 py-0.5 rounded-full font-medium text-gray-600 dark:text-gray-300">
                      {tx.paymentMethod}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className={`text-base font-extrabold ${
                  tx.type === 'income' ? 'text-emerald-500' : 'text-rose-500'
                }`}>
                  {settings.isPrivacyMode ? '₹ • • •' : `${tx.type === 'income' ? '+' : '-'}${settings.currency}${tx.amount.toLocaleString()}`}
                </span>

                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => openEditModal(tx)}
                    className="p-1.5 rounded-xl hover:bg-gray-200 dark:hover:bg-white/10 text-gray-500"
                    title="Edit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => archiveTransaction(tx.id)}
                    className="p-1.5 rounded-xl hover:bg-purple-100 text-purple-600"
                    title="Archive"
                  >
                    <Archive className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteTransaction(tx.id)}
                    className="p-1.5 rounded-xl hover:bg-rose-100 text-rose-500"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
