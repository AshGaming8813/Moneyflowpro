import React from 'react';
import { useApp } from '../../context/AppContext';
import { Trophy, Award, Gift, Sparkles, CheckCircle2, Share2, Flame } from 'lucide-react';
import { motion } from 'framer-motion';

export const WeeklyChallengesView: React.FC = () => {
  const { weeklyChallenges, badges, settings, completeChallenge, showToast, triggerConfetti } = useApp();

  const handleShareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'MoneyFlow App',
        text: `Join MoneyFlow - The ultimate smart finance app! Use my invite code: MONEY${settings.userName.toUpperCase()}100`,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(`Join MoneyFlow - Use invite code: MONEY${settings.userName.toUpperCase()}100`);
      showToast('Referral code copied to clipboard!', 'success');
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-fadeIn">
      {/* Title */}
      <div>
        <h2 className="text-2xl font-black text-gray-800 dark:text-white flex items-center gap-2">
          Challenges & Rewards 🏆
        </h2>
        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
          Earn reward points, complete weekly challenges & invite friends
        </p>
      </div>

      {/* Reward Points Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-md">
            <Gift className="w-6 h-6 text-amber-200" />
          </div>
          <div>
            <span className="text-xs font-semibold text-amber-100 uppercase">Available Reward Points</span>
            <p className="text-3xl font-black">{settings.referralPoints} PTS 🪙</p>
          </div>
        </div>

        <button
          onClick={handleShareReferral}
          className="px-3.5 py-2 rounded-2xl bg-white text-orange-600 font-extrabold text-xs shadow-md flex items-center gap-1.5 hover:bg-amber-50 transition-all"
        >
          <Share2 className="w-4 h-4" /> Refer & Earn
        </button>
      </div>

      {/* Weekly Challenges List */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500 px-1">
          Active Weekly Challenges
        </h3>

        <div className="space-y-3">
          {weeklyChallenges.map(ch => (
            <div
              key={ch.id}
              className="p-4 rounded-3xl glass-card border border-white/20 flex items-center justify-between"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-extrabold text-sm text-gray-900 dark:text-white">{ch.title}</h4>
                  <span className="bg-amber-500/20 text-amber-600 dark:text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    +{ch.rewardPoints} PTS
                  </span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">{ch.targetDescription}</p>
              </div>

              {!ch.completed ? (
                <button
                  onClick={() => completeChallenge(ch.id)}
                  className="px-3.5 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs shadow-md hover:bg-purple-700 transition-all shrink-0"
                >
                  Claim Reward
                </button>
              ) : (
                <span className="flex items-center gap-1 text-xs font-bold text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-xl">
                  <CheckCircle2 className="w-4 h-4" /> Claimed
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
