import type { CategoryInfo, Transaction, SavingsGoal, Bill, Badge, UserSettings } from '../types';

export const CATEGORIES: CategoryInfo[] = [
  { name: 'Food', icon: 'Utensils', color: 'bg-amber-500 text-white', type: 'expense' },
  { name: 'Shopping', icon: 'ShoppingBag', color: 'bg-pink-500 text-white', type: 'expense' },
  { name: 'Fuel', icon: 'Fuel', color: 'bg-orange-500 text-white', type: 'expense' },
  { name: 'Travel', icon: 'Plane', color: 'bg-blue-500 text-white', type: 'expense' },
  { name: 'Recharge', icon: 'Smartphone', color: 'bg-cyan-500 text-white', type: 'expense' },
  { name: 'Medicine', icon: 'HeartPulse', color: 'bg-red-500 text-white', type: 'expense' },
  { name: 'Education', icon: 'GraduationCap', color: 'bg-indigo-500 text-white', type: 'expense' },
  { name: 'Rent', icon: 'Home', color: 'bg-purple-500 text-white', type: 'expense' },
  { name: 'Entertainment', icon: 'Tv', color: 'bg-violet-500 text-white', type: 'expense' },
  { name: 'Salary', icon: 'Briefcase', color: 'bg-emerald-500 text-white', type: 'income' },
  { name: 'Business', icon: 'Building2', color: 'bg-teal-500 text-white', type: 'income' },
  { name: 'Freelancing', icon: 'Laptop', color: 'bg-sky-500 text-white', type: 'income' },
  { name: 'Investment', icon: 'TrendingUp', color: 'bg-green-600 text-white', type: 'both' },
  { name: 'Gift', icon: 'Gift', color: 'bg-rose-500 text-white', type: 'both' },
  { name: 'Interest', icon: 'Percent', color: 'bg-emerald-600 text-white', type: 'income' },
  { name: 'Others', icon: 'MoreHorizontal', color: 'bg-gray-500 text-white', type: 'both' },
];

// Start fresh with zero initial money entries as requested!
export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_GOALS: SavingsGoal[] = [];

export const INITIAL_BILLS: Bill[] = [];

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'badge-1',
    title: '7 Day Saving Streak',
    description: 'Log expenses for 7 consecutive days',
    icon: 'Flame',
    unlocked: false,
    progress: 0,
    maxProgress: 7
  },
  {
    id: 'badge-2',
    title: '30 Day Expense Tracking',
    description: 'Track expenses for an entire month',
    icon: 'Calendar',
    unlocked: false,
    progress: 0,
    maxProgress: 30
  },
  {
    id: 'badge-3',
    title: 'First Goal Completed',
    description: 'Reach 100% target on any savings goal',
    icon: 'Trophy',
    unlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'badge-4',
    title: '100 Transactions',
    description: 'Log 100 total transactions in MoneyFlow',
    icon: 'Zap',
    unlocked: false,
    progress: 0,
    maxProgress: 100
  },
  {
    id: 'badge-5',
    title: 'Money Master',
    description: 'Keep expenses under 50% of income',
    icon: 'Crown',
    unlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'badge-6',
    title: 'Gold Saver',
    description: 'Save over ₹50,000 in your total balance',
    icon: 'Award',
    unlocked: false,
    progress: 0,
    maxProgress: 50000
  }
];

export const DEFAULT_USER_SETTINGS: UserSettings = {
  theme: 'light',
  accentColor: 'purple',
  language: 'en',
  currency: '₹',
  userName: 'User',
  userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
  activeWallet: 'personal',
  isPrivacyMode: false,
  securityLockEnabled: false,
  pin: '1234',
  biometricEnabled: true,
  notificationsEnabled: true,
  dailyReminderTime: '20:00',
  budgetLimit: 30000,
  dailyLimit: 1500,
  paydayDate: 1,
  referralPoints: 0
};
