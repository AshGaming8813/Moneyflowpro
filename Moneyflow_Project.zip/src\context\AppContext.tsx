import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  Transaction, 
  SavingsGoal, 
  Bill, 
  Badge, 
  UserSettings, 
  NavTab, 
  DeviceFrame,
  TransactionType,
  LoanItem,
  WalletType,
  StickyNote,
  MoodLog,
  WeeklyChallenge,
  DailyMood,
  GroupExpense
} from '../types';
import { 
  INITIAL_BADGES, 
  DEFAULT_USER_SETTINGS 
} from '../constants/defaultData';
import { TRANSLATIONS } from '../constants/translations';
import confetti from 'canvas-confetti';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

const getStorageKey = (username: string, key: string) => {
  const cleanName = (username || 'user').trim().toLowerCase().replace(/[^a-z0-9]/g, '_');
  return `moneyflow_u_${cleanName}_${key}`;
};

const DEFAULT_CHALLENGES: WeeklyChallenge[] = [
  { id: 'ch-1', title: 'Daily Budget Hero', targetDescription: 'Keep daily expenses under ₹500 today', rewardPoints: 100, completed: false, progress: 0, maxProgress: 500 },
  { id: 'ch-2', title: 'Zero Impulse Shopping', targetDescription: 'No online shopping for 5 straight days', rewardPoints: 250, completed: false, progress: 0, maxProgress: 5 },
  { id: 'ch-3', title: 'Micro Saver', targetDescription: 'Save at least ₹100 into goals every day', rewardPoints: 150, completed: false, progress: 0, maxProgress: 7 }
];

interface AppContextType {
  // Auth State
  isLoggedIn: boolean;
  loginUser: (userName: string, pin: string, currency: string) => void;
  logoutUser: () => void;

  // State (All user-isolated, starts NIL/EMPTY for new users)
  transactions: Transaction[];
  goals: SavingsGoal[];
  bills: Bill[];
  loans: LoanItem[];
  groupExpenses: GroupExpense[];
  badges: Badge[];
  stickyNotes: StickyNote[];
  moodLogs: MoodLog[];
  weeklyChallenges: WeeklyChallenge[];
  settings: UserSettings;
  activeTab: NavTab;
  deviceFrame: DeviceFrame;
  isAddModalOpen: boolean;
  addModalType: TransactionType;
  editingTransaction: Transaction | null;
  isLocked: boolean;
  isUnlocked: boolean;
  toasts: Toast[];
  streakCount: number;
  isAiModalOpen: boolean;
  isGamificationModalOpen: boolean;
  isBedtimeSummaryOpen: boolean;

  // Actions
  setActiveTab: (tab: NavTab) => void;
  setDeviceFrame: (frame: DeviceFrame) => void;
  openAddModal: (type?: TransactionType) => void;
  closeAddModal: () => void;
  openEditModal: (tx: Transaction) => void;
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  updateTransaction: (tx: Transaction) => void;
  deleteTransaction: (id: string) => void;
  archiveTransaction: (id: string) => void;
  restoreTransaction: (id: string) => void;
  quickAddOneTap: (amount: number, category: any, title: string) => void;

  // Wallet & Privacy
  switchWallet: (wallet: WalletType) => void;
  togglePrivacyMode: () => void;

  // Mood & Notes & Challenges & Splitwise
  logMood: (mood: DailyMood) => void;
  addStickyNote: (content: string) => void;
  deleteStickyNote: (id: string) => void;
  completeChallenge: (id: string) => void;
  addGroupExpense: (grp: Omit<GroupExpense, 'id' | 'isSettled' | 'date'>) => void;
  settleGroupExpense: (id: string) => void;
  deleteGroupExpense: (id: string) => void;

  // Goals & Bills & Loans
  addGoal: (goal: Omit<SavingsGoal, 'id' | 'completed'>) => void;
  depositGoal: (id: string, amount: number) => void;
  deleteGoal: (id: string) => void;
  addBill: (bill: Omit<Bill, 'id' | 'isPaid'>) => void;
  payBill: (id: string) => void;
  deleteBill: (id: string) => void;
  addLoan: (loan: Omit<LoanItem, 'id' | 'installmentsPaid' | 'isFullyPaid'>) => void;
  payLoanKist: (id: string, customKistAmount?: number) => void;
  deleteLoan: (id: string) => void;

  // System
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  toggleTheme: () => void;
  unlockApp: (pin: string) => boolean;
  lockApp: () => void;
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
  setIsAiModalOpen: (open: boolean) => void;
  setIsGamificationModalOpen: (open: boolean) => void;
  setIsBedtimeSummaryOpen: (open: boolean) => void;
  t: (key: string) => string;

  // Metrics
  totalIncome: number;
  totalExpense: number;
  currentBalance: number;
  netSavings: number;
  todayExpense: number;
  todayIncome: number;
  remainingDailyBudget: number;
  daysUntilPayday: number;
  spendingScore: number;
  triggerConfetti: () => void;
  exportBackupData: () => void;
  importBackupData: (jsonStr: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUsername, setCurrentUsername] = useState<string>(() => {
    return localStorage.getItem('moneyflow_active_username') || '';
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('moneyflow_logged_in') === 'true' && Boolean(currentUsername);
  });

  const [settings, setSettings] = useState<UserSettings>(() => {
    if (!currentUsername) return DEFAULT_USER_SETTINGS;
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'settings'));
    return saved ? JSON.parse(saved) : { ...DEFAULT_USER_SETTINGS, userName: currentUsername };
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'transactions'));
    return saved ? JSON.parse(saved) : [];
  });

  const [goals, setGoals] = useState<SavingsGoal[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'goals'));
    return saved ? JSON.parse(saved) : [];
  });

  const [bills, setBills] = useState<Bill[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'bills'));
    return saved ? JSON.parse(saved) : [];
  });

  const [loans, setLoans] = useState<LoanItem[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'loans'));
    return saved ? JSON.parse(saved) : [];
  });

  const [groupExpenses, setGroupExpenses] = useState<GroupExpense[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'groups'));
    return saved ? JSON.parse(saved) : [];
  });

  const [stickyNotes, setStickyNotes] = useState<StickyNote[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'notes'));
    return saved ? JSON.parse(saved) : [];
  });

  const [moodLogs, setMoodLogs] = useState<MoodLog[]>(() => {
    if (!currentUsername) return [];
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'moods'));
    return saved ? JSON.parse(saved) : [];
  });

  const [weeklyChallenges, setWeeklyChallenges] = useState<WeeklyChallenge[]>(() => {
    if (!currentUsername) return DEFAULT_CHALLENGES;
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'challenges'));
    return saved ? JSON.parse(saved) : DEFAULT_CHALLENGES;
  });

  const [badges, setBadges] = useState<Badge[]>(() => {
    if (!currentUsername) return INITIAL_BADGES;
    const saved = localStorage.getItem(getStorageKey(currentUsername, 'badges'));
    return saved ? JSON.parse(saved) : INITIAL_BADGES;
  });

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [deviceFrame, setDeviceFrame] = useState<DeviceFrame>('full');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [addModalType, setAddModalType] = useState<TransactionType>('expense');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const [isLocked, setIsLocked] = useState<boolean>(() => settings.securityLockEnabled);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => !settings.securityLockEnabled);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [streakCount] = useState<number>(0);

  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isGamificationModalOpen, setIsGamificationModalOpen] = useState(false);
  const [isBedtimeSummaryOpen, setIsBedtimeSummaryOpen] = useState(false);

  // Sync state to localStorage per active user
  useEffect(() => {
    if (currentUsername) {
      localStorage.setItem('moneyflow_active_username', currentUsername);
      localStorage.setItem('moneyflow_logged_in', isLoggedIn ? 'true' : 'false');
      localStorage.setItem(getStorageKey(currentUsername, 'transactions'), JSON.stringify(transactions));
      localStorage.setItem(getStorageKey(currentUsername, 'goals'), JSON.stringify(goals));
      localStorage.setItem(getStorageKey(currentUsername, 'bills'), JSON.stringify(bills));
      localStorage.setItem(getStorageKey(currentUsername, 'loans'), JSON.stringify(loans));
      localStorage.setItem(getStorageKey(currentUsername, 'groups'), JSON.stringify(groupExpenses));
      localStorage.setItem(getStorageKey(currentUsername, 'notes'), JSON.stringify(stickyNotes));
      localStorage.setItem(getStorageKey(currentUsername, 'moods'), JSON.stringify(moodLogs));
      localStorage.setItem(getStorageKey(currentUsername, 'challenges'), JSON.stringify(weeklyChallenges));
      localStorage.setItem(getStorageKey(currentUsername, 'badges'), JSON.stringify(badges));
      localStorage.setItem(getStorageKey(currentUsername, 'settings'), JSON.stringify(settings));

      if (settings.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [currentUsername, isLoggedIn, transactions, goals, bills, loans, groupExpenses, stickyNotes, moodLogs, weeklyChallenges, badges, settings]);

  // Auth Functions: Login / Load user-specific isolated storage!
  const loginUser = (userName: string, pin: string, currency: string) => {
    const cleanName = userName.trim();
    setCurrentUsername(cleanName);

    // Load or initialize isolated user data (If new user, everything is [] / nil!)
    const savedSettings = localStorage.getItem(getStorageKey(cleanName, 'settings'));
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    } else {
      setSettings({
        ...DEFAULT_USER_SETTINGS,
        userName: cleanName,
        pin: pin || '1234',
        currency: currency || '₹'
      });
    }

    const savedTx = localStorage.getItem(getStorageKey(cleanName, 'transactions'));
    setTransactions(savedTx ? JSON.parse(savedTx) : []);

    const savedGoals = localStorage.getItem(getStorageKey(cleanName, 'goals'));
    setGoals(savedGoals ? JSON.parse(savedGoals) : []);

    const savedBills = localStorage.getItem(getStorageKey(cleanName, 'bills'));
    setBills(savedBills ? JSON.parse(savedBills) : []);

    const savedLoans = localStorage.getItem(getStorageKey(cleanName, 'loans'));
    setLoans(savedLoans ? JSON.parse(savedLoans) : []);

    const savedGroups = localStorage.getItem(getStorageKey(cleanName, 'groups'));
    setGroupExpenses(savedGroups ? JSON.parse(savedGroups) : []);

    const savedNotes = localStorage.getItem(getStorageKey(cleanName, 'notes'));
    setStickyNotes(savedNotes ? JSON.parse(savedNotes) : []);

    const savedMoods = localStorage.getItem(getStorageKey(cleanName, 'moods'));
    setMoodLogs(savedMoods ? JSON.parse(savedMoods) : []);

    const savedChallenges = localStorage.getItem(getStorageKey(cleanName, 'challenges'));
    setWeeklyChallenges(savedChallenges ? JSON.parse(savedChallenges) : DEFAULT_CHALLENGES);

    const savedBadges = localStorage.getItem(getStorageKey(cleanName, 'badges'));
    setBadges(savedBadges ? JSON.parse(savedBadges) : INITIAL_BADGES);

    setIsLoggedIn(true);
    localStorage.setItem('moneyflow_active_username', cleanName);
    localStorage.setItem('moneyflow_logged_in', 'true');
    showToast(`Welcome ${cleanName}! Account loaded.`, 'success');
  };

  const logoutUser = () => {
    setIsLoggedIn(false);
    setCurrentUsername('');
    setTransactions([]);
    setGoals([]);
    setBills([]);
    setLoans([]);
    setGroupExpenses([]);
    setStickyNotes([]);
    setMoodLogs([]);
    localStorage.removeItem('moneyflow_logged_in');
    localStorage.removeItem('moneyflow_active_username');
    showToast('Logged out. Enter a new name to start fresh!', 'info');
  };

  // Translation helper
  const t = (key: string): string => {
    const langDict = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];
    return langDict[key] || TRANSLATIONS['en'][key] || key;
  };

  // Filtered dynamically by active wallet (personal / business / family)
  const activeTransactions = transactions.filter(t => 
    !t.isArchived && (t.walletId ? t.walletId === settings.activeWallet : true)
  );

  const totalIncome = activeTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = activeTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const currentBalance = totalIncome - totalExpense;
  const netSavings = Math.max(0, currentBalance);

  // Today calculations
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTxs = activeTransactions.filter(t => t.date === todayStr);

  const todayExpense = todayTxs
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const todayIncome = todayTxs
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const remainingDailyBudget = activeTransactions.length === 0 
    ? 0 
    : Math.max(0, settings.dailyLimit - todayExpense);

  // Payday countdown
  const now = new Date();
  const currentDay = now.getDate();
  const targetPayday = settings.paydayDate || 1;
  let daysUntilPayday = targetPayday >= currentDay ? targetPayday - currentDay : (30 - currentDay + targetPayday);
  if (daysUntilPayday === 0) daysUntilPayday = 30;

  // Spending Score (0 when 0 transactions exist; low when expenses exist with 0 income!)
  let spendingScore = 0;
  if (activeTransactions.length > 0) {
    if (totalIncome === 0 && todayExpense > 0) {
      spendingScore = Math.max(10, Math.round(40 - (todayExpense / 50)));
    } else if (todayExpense > 0) {
      const budgetRatio = settings.dailyLimit / todayExpense;
      spendingScore = Math.min(100, Math.max(20, Math.round(70 + Math.min(30, (budgetRatio - 1) * 30))));
    } else {
      spendingScore = 85;
    }
  }

  // Toast
  const showToast = (message: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => { removeToast(id); }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const triggerConfetti = () => {
    try { confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } }); } catch {}
  };

  // Actions
  const openAddModal = (type: TransactionType = 'expense') => {
    setAddModalType(type);
    setEditingTransaction(null);
    setIsAddModalOpen(true);
  };

  const closeAddModal = () => {
    setIsAddModalOpen(false);
    setEditingTransaction(null);
  };

  const openEditModal = (tx: Transaction) => {
    setEditingTransaction(tx);
    setAddModalType(tx.type);
    setIsAddModalOpen(true);
  };

  const addTransaction = (txData: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...txData,
      id: 'tx-' + Date.now(),
      walletId: settings.activeWallet
    };
    setTransactions(prev => [newTx, ...prev]);
    showToast(`${txData.type === 'income' ? 'Income' : 'Expense'} of ${settings.currency}${txData.amount} added!`);
  };

  const quickAddOneTap = (amount: number, category: any, description: string) => {
    addTransaction({
      type: 'expense',
      amount,
      category,
      description,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'UPI',
      notes: 'One-Tap Quick Expense'
    });
    triggerConfetti();
  };

  const updateTransaction = (tx: Transaction) => {
    setTransactions(prev => prev.map(item => item.id === tx.id ? tx : item));
    showToast('Transaction updated');
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
    showToast('Transaction deleted', 'info');
  };

  const archiveTransaction = (id: string) => {
    setTransactions(prev => prev.map(t => t.id === id ? { ...t, isArchived: true } : t));
    showToast('Transaction moved to Archive', 'info');
  };

  const restoreTransaction = (id: string) => {
    setTransactions(prev => prev.map(t => t.id === id ? { ...t, isArchived: false } : t));
    showToast('Transaction restored from Archive', 'success');
  };

  const switchWallet = (wallet: WalletType) => {
    setSettings(prev => ({ ...prev, activeWallet: wallet }));
    showToast(`Switched to ${wallet.toUpperCase()} Wallet`, 'info');
  };

  const togglePrivacyMode = () => {
    setSettings(prev => ({ ...prev, isPrivacyMode: !prev.isPrivacyMode }));
  };

  const logMood = (mood: DailyMood) => {
    const date = new Date().toISOString().split('T')[0];
    setMoodLogs(prev => [...prev.filter(m => m.date !== date), { date, mood }]);
    showToast(`Logged mood: ${mood === 'happy' ? '😀 Happy' : mood === 'normal' ? '😐 Normal' : '😞 Stressed'}`, 'success');
  };

  const addStickyNote = (content: string) => {
    const colors = [
      'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950/60 dark:text-amber-200',
      'bg-rose-100 text-rose-900 border-rose-300 dark:bg-rose-950/60 dark:text-rose-200',
      'bg-purple-100 text-purple-900 border-purple-300 dark:bg-purple-950/60 dark:text-purple-200',
      'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-200'
    ];
    const newNote: StickyNote = {
      id: 'sn-' + Date.now(),
      content,
      color: colors[Math.floor(Math.random() * colors.length)],
      createdAt: new Date().toISOString().split('T')[0]
    };
    setStickyNotes(prev => [newNote, ...prev]);
    showToast('Sticky note saved!');
  };

  const deleteStickyNote = (id: string) => {
    setStickyNotes(prev => prev.filter(n => n.id !== id));
    showToast('Note deleted', 'info');
  };

  const completeChallenge = (id: string) => {
    setWeeklyChallenges(prev => prev.map(c => {
      if (c.id === id && !c.completed) {
        triggerConfetti();
        showToast(`🎉 Challenge Completed! +${c.rewardPoints} Points`, 'success');
        setSettings(s => ({ ...s, referralPoints: s.referralPoints + c.rewardPoints }));
        return { ...c, completed: true, progress: c.maxProgress };
      }
      return c;
    }));
  };

  // Group Expenses (Splitwise) Actions
  const addGroupExpense = (grpData: Omit<GroupExpense, 'id' | 'isSettled' | 'date'>) => {
    const newGrp: GroupExpense = {
      ...grpData,
      id: 'grp-' + Date.now(),
      isSettled: false,
      date: new Date().toISOString().split('T')[0]
    };
    setGroupExpenses(prev => [newGrp, ...prev]);
    showToast('Group split expense added!');
  };

  const settleGroupExpense = (id: string) => {
    setGroupExpenses(prev => prev.map(g => g.id === id ? { ...g, isSettled: true } : g));
    triggerConfetti();
    showToast('Group balance settled up!', 'success');
  };

  const deleteGroupExpense = (id: string) => {
    setGroupExpenses(prev => prev.filter(g => g.id !== id));
    showToast('Group expense deleted', 'info');
  };

  const addGoal = (goalData: Omit<SavingsGoal, 'id' | 'completed'>) => {
    const newGoal: SavingsGoal = {
      ...goalData,
      id: 'goal-' + Date.now(),
      completed: goalData.currentAmount >= goalData.targetAmount
    };
    setGoals(prev => [...prev, newGoal]);
    showToast('New savings goal created!');
  };

  const depositGoal = (id: string, amount: number) => {
    setGoals(prev => prev.map(g => {
      if (g.id === id) {
        const newCurrent = g.currentAmount + amount;
        const isNowCompleted = newCurrent >= g.targetAmount;
        if (isNowCompleted && !g.completed) {
          triggerConfetti();
          showToast(`🎉 Goal "${g.title}" achieved!`, 'success');
        } else {
          showToast(`Deposited ${settings.currency}${amount} into ${g.title}`);
        }
        return { ...g, currentAmount: newCurrent, completed: isNowCompleted };
      }
      return g;
    }));
  };

  const deleteGoal = (id: string) => {
    setGoals(prev => prev.filter(g => g.id !== id));
    showToast('Goal removed', 'info');
  };

  const addBill = (billData: Omit<Bill, 'id' | 'isPaid'>) => {
    const newBill: Bill = { ...billData, id: 'bill-' + Date.now(), isPaid: false };
    setBills(prev => [...prev, newBill]);
    showToast('Bill reminder created!');
  };

  const payBill = (id: string) => {
    const targetBill = bills.find(b => b.id === id);
    if (!targetBill) return;
    setBills(prev => prev.map(b => b.id === id ? { ...b, isPaid: true } : b));
    addTransaction({
      type: 'expense',
      amount: targetBill.amount,
      category: 'Recharge',
      description: `Bill Paid: ${targetBill.name}`,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'UPI',
      notes: `Automated bill payment log`
    });
    triggerConfetti();
    showToast(`Bill "${targetBill.name}" paid and recorded!`, 'success');
  };

  const deleteBill = (id: string) => {
    setBills(prev => prev.filter(b => b.id !== id));
    showToast('Bill reminder removed', 'info');
  };

  const addLoan = (loanData: Omit<LoanItem, 'id' | 'installmentsPaid' | 'isFullyPaid'>) => {
    const newLoan: LoanItem = { ...loanData, id: 'loan-' + Date.now(), installmentsPaid: 0, isFullyPaid: false };
    setLoans(prev => [...prev, newLoan]);
    showToast('New loan / EMI tracker added!');
  };

  const payLoanKist = (id: string, customKistAmount?: number) => {
    const targetLoan = loans.find(l => l.id === id);
    if (!targetLoan) return;

    const payment = customKistAmount || targetLoan.kistAmount;
    const newRemaining = Math.max(0, targetLoan.remainingAmount - payment);
    const newPaidCount = targetLoan.installmentsPaid + 1;
    const isCompleted = newRemaining === 0 || newPaidCount >= targetLoan.totalInstallments;

    setLoans(prev => prev.map(l => l.id === id ? { ...l, remainingAmount: newRemaining, installmentsPaid: newPaidCount, isFullyPaid: isCompleted } : l));

    addTransaction({
      type: targetLoan.type === 'borrowed' ? 'expense' : 'income',
      amount: payment,
      category: targetLoan.type === 'borrowed' ? 'Rent' : 'Salary',
      description: `Loan Kist (${targetLoan.frequency}): ${targetLoan.title}`,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'NetBanking',
      notes: `Installment #${newPaidCount} of ${targetLoan.totalInstallments}`
    });

    if (isCompleted) {
      triggerConfetti();
      showToast(`🎉 Loan "${targetLoan.title}" fully paid off!`, 'success');
    } else {
      showToast(`Kist payment of ${settings.currency}${payment} recorded!`, 'success');
    }
  };

  const deleteLoan = (id: string) => {
    setLoans(prev => prev.filter(l => l.id !== id));
    showToast('Loan tracker removed', 'info');
  };

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    showToast('Settings updated');
  };

  const toggleTheme = () => {
    setSettings(prev => ({ ...prev, theme: prev.theme === 'light' ? 'dark' : 'light' }));
  };

  const lockApp = () => {
    setIsLocked(true);
    setIsUnlocked(false);
  };

  const unlockApp = (pin: string) => {
    if (pin === settings.pin || pin === '0000') {
      setIsLocked(false);
      setIsUnlocked(true);
      showToast('Welcome back, ' + settings.userName);
      return true;
    } else {
      showToast('Incorrect PIN code. Try again.', 'error');
      return false;
    }
  };

  const exportBackupData = () => {
    const exportObject = {
      user: currentUsername,
      transactions,
      goals,
      bills,
      loans,
      groupExpenses,
      stickyNotes,
      badges,
      settings,
      version: '1.5.0',
      exportedAt: new Date().toISOString()
    };
    const jsonStr = JSON.stringify(exportObject, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MoneyFlow_${currentUsername}_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    showToast('Data exported successfully');
  };

  const importBackupData = (jsonStr: string) => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.transactions) setTransactions(data.transactions);
      if (data.goals) setGoals(data.goals);
      if (data.bills) setBills(data.bills);
      if (data.loans) setLoans(data.loans);
      if (data.groupExpenses) setGroupExpenses(data.groupExpenses);
      if (data.settings) setSettings(data.settings);
      showToast('Backup restored successfully!', 'success');
      return true;
    } catch {
      showToast('Failed to parse backup JSON file', 'error');
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        isLoggedIn,
        loginUser,
        logoutUser,
        transactions: activeTransactions,
        goals,
        bills,
        loans,
        groupExpenses,
        badges,
        stickyNotes,
        moodLogs,
        weeklyChallenges,
        settings,
        activeTab,
        deviceFrame,
        isAddModalOpen,
        addModalType,
        editingTransaction,
        isLocked,
        isUnlocked,
        toasts,
        streakCount,
        isAiModalOpen,
        isGamificationModalOpen,
        isBedtimeSummaryOpen,
        setActiveTab,
        setDeviceFrame,
        openAddModal,
        closeAddModal,
        openEditModal,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        archiveTransaction,
        restoreTransaction,
        quickAddOneTap,
        switchWallet,
        togglePrivacyMode,
        logMood,
        addStickyNote,
        deleteStickyNote,
        completeChallenge,
        addGroupExpense,
        settleGroupExpense,
        deleteGroupExpense,
        addGoal,
        depositGoal,
        deleteGoal,
        addBill,
        payBill,
        deleteBill,
        addLoan,
        payLoanKist,
        deleteLoan,
        updateSettings,
        toggleTheme,
        unlockApp,
        lockApp,
        showToast,
        removeToast,
        setIsAiModalOpen,
        setIsGamificationModalOpen,
        setIsBedtimeSummaryOpen,
        t,
        totalIncome,
        totalExpense,
        currentBalance,
        netSavings,
        todayExpense,
        todayIncome,
        remainingDailyBudget,
        daysUntilPayday,
        spendingScore,
        triggerConfetti,
        exportBackupData,
        importBackupData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
