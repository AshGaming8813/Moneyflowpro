export type TransactionType = 'income' | 'expense';

export type PaymentMethod = 'Cash' | 'UPI' | 'Card' | 'NetBanking';

export type WalletType = 'personal' | 'business' | 'family';

export type AppLanguage = 'en' | 'hi' | 'mr' | 'pa' | 'gu' | 'ta' | 'bn';

export type DailyMood = 'happy' | 'normal' | 'stressed';

export type CategoryName = 
  | 'Food' 
  | 'Shopping' 
  | 'Fuel' 
  | 'Travel' 
  | 'Recharge' 
  | 'Medicine' 
  | 'Education' 
  | 'Rent' 
  | 'Entertainment' 
  | 'Salary' 
  | 'Business' 
  | 'Investment' 
  | 'Gift' 
  | 'Freelancing'
  | 'Interest'
  | 'Others';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: CategoryName;
  description: string;
  date: string; // ISO string YYYY-MM-DD
  paymentMethod: PaymentMethod;
  notes?: string;
  billPhoto?: string;
  source?: string;
  walletId?: WalletType;
  isFavorite?: boolean;
  isArchived?: boolean;
}

export interface FavoriteQuickExpense {
  id: string;
  title: string;
  category: CategoryName;
  amount: number;
  icon: string;
}

export interface StickyNote {
  id: string;
  content: string;
  color: string;
  createdAt: string;
}

export interface MoodLog {
  date: string; // YYYY-MM-DD
  mood: DailyMood;
}

export interface WeeklyChallenge {
  id: string;
  title: string;
  targetDescription: string;
  rewardPoints: number;
  completed: boolean;
  progress: number;
  maxProgress: number;
}

export interface CategoryInfo {
  name: CategoryName;
  icon: string;
  color: string;
  type: TransactionType | 'both';
}

export interface SavingsGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  category: string;
  deadline?: string;
  color: string;
  icon: string;
  completed: boolean;
}

export type BillCategory = 
  | 'Electricity' 
  | 'Water' 
  | 'Gas' 
  | 'Internet' 
  | 'Netflix' 
  | 'Phone Recharge' 
  | 'EMI' 
  | 'Insurance' 
  | 'Custom';

export interface Bill {
  id: string;
  name: string;
  category: BillCategory;
  amount: number;
  dueDate: string;
  reminderTime: string;
  repeat: 'Daily' | 'Weekly' | 'Monthly' | 'Yearly' | 'None';
  isPaid: boolean;
  autoNotify: boolean;
}

export interface LoanItem {
  id: string;
  title: string;
  type: 'borrowed' | 'given';
  totalAmount: number;
  remainingAmount: number;
  kistAmount: number;
  frequency: 'Monthly' | 'Weekly' | 'Yearly';
  nextDueDate: string;
  interestRate: number;
  installmentsPaid: number;
  totalInstallments: number;
  isFullyPaid: boolean;
  notes?: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
}

export interface GroupExpense {
  id: string;
  groupName: string;
  description: string;
  totalAmount: number;
  paidBy: string;
  members: string[];
  splitAmountPerPerson: number;
  isSettled: boolean;
  date: string;
}

export interface UserSettings {
  theme: 'light' | 'dark';
  accentColor: 'purple' | 'blue' | 'emerald' | 'orange' | 'pink';
  language: AppLanguage;
  currency: string;
  userName: string;
  userAvatar: string;
  activeWallet: WalletType;
  isPrivacyMode: boolean;
  securityLockEnabled: boolean;
  pin: string;
  biometricEnabled: boolean;
  notificationsEnabled: boolean;
  dailyReminderTime: string;
  budgetLimit: number;
  dailyLimit: number;
  paydayDate: number;
  referralPoints: number;
}

export type NavTab = 
  | 'home' 
  | 'transactions' 
  | 'reports' 
  | 'goals' 
  | 'settings' 
  | 'calendar' 
  | 'bills' 
  | 'splitwise' 
  | 'loans'
  | 'archive'
  | 'challenges';

export type DeviceFrame = 'android' | 'ios' | 'full';
